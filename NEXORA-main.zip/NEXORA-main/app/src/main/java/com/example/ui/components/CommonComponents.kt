package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MessageDeliveryStatus
import com.example.data.model.UserPresence
import com.example.ui.theme.*

@Composable
fun UserAvatar(
    initials: String,
    backgroundColor: Long,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    presence: UserPresence? = null,
    isSpeaking: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_speak")
    val speakScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isSpeaking) 1.15f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "speak_scale"
    )

    Box(
        modifier = modifier
            .size(size)
            .then(
                if (isSpeaking) {
                    Modifier.border(2.5.dp, DiscordGreen, CircleShape)
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(Color(backgroundColor)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = initials.take(2),
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = (size.value * 0.4f).sp
            )
        }

        // Presence dot
        if (presence != null) {
            val (dotColor, borderColor) = when (presence) {
                UserPresence.ONLINE -> DiscordGreen to Color(0xFF1E1F22)
                UserPresence.IDLE -> DiscordYellow to Color(0xFF1E1F22)
                UserPresence.DND -> DiscordRed to Color(0xFF1E1F22)
                UserPresence.OFFLINE -> Color(0xFF80848E) to Color(0xFF1E1F22)
            }

            Box(
                modifier = Modifier
                    .size(size * 0.32f)
                    .align(Alignment.BottomEnd)
                    .clip(CircleShape)
                    .background(dotColor)
                    .border(1.5.dp, borderColor, CircleShape)
            )
        }
    }
}

@Composable
fun MessageDeliveryIcon(
    status: MessageDeliveryStatus,
    modifier: Modifier = Modifier
) {
    when (status) {
        MessageDeliveryStatus.SENDING -> {
            Box(
                modifier = modifier
                    .size(12.dp)
                    .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape)
            )
        }
        MessageDeliveryStatus.SENT -> {
            Icon(
                imageVector = Icons.Default.Done,
                contentDescription = "Sent",
                tint = Color.White.copy(alpha = 0.7f),
                modifier = modifier.size(14.dp)
            )
        }
        MessageDeliveryStatus.DELIVERED -> {
            Icon(
                imageVector = Icons.Default.DoneAll,
                contentDescription = "Delivered",
                tint = Color.White.copy(alpha = 0.7f),
                modifier = modifier.size(14.dp)
            )
        }
        MessageDeliveryStatus.READ -> {
            Icon(
                imageVector = Icons.Default.DoneAll,
                contentDescription = "Read",
                tint = WhatsAppTickBlue,
                modifier = modifier.size(14.dp)
            )
        }
    }
}

@Composable
fun AudioWaveform(
    isPlaying: Boolean,
    progress: Float,
    modifier: Modifier = Modifier,
    barCount: Int = 28,
    activeColor: Color = WhatsAppTickBlue,
    inactiveColor: Color = Color.White.copy(alpha = 0.35f)
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave_anim")
    val waveOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = if (isPlaying) 1f else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "offset"
    )

    Canvas(modifier = modifier.fillMaxWidth().height(26.dp)) {
        val width = size.width
        val height = size.height
        val barWidth = width / (barCount * 1.6f)
        val gap = (width - (barCount * barWidth)) / (barCount - 1)

        val heightsPattern = floatArrayOf(
            0.3f, 0.6f, 0.9f, 0.5f, 0.8f, 0.4f, 0.7f, 1.0f, 0.6f, 0.3f,
            0.8f, 0.9f, 0.4f, 0.6f, 0.7f, 0.3f, 0.8f, 0.5f, 0.9f, 0.7f,
            0.4f, 0.6f, 0.8f, 0.5f, 0.7f, 0.4f, 0.8f, 0.3f
        )

        for (i in 0 until barCount) {
            val baseH = heightsPattern[i % heightsPattern.size]
            val animatedH = if (isPlaying) {
                val cycle = ((i.toFloat() / barCount) + waveOffset) % 1f
                (baseH * (0.6f + 0.4f * kotlin.math.sin(cycle * 2 * Math.PI).toFloat())).coerceIn(0.2f, 1.0f)
            } else baseH

            val barH = height * animatedH
            val x = i * (barWidth + gap)
            val yStart = (height - barH) / 2
            val yEnd = yStart + barH

            val isPlayed = (i.toFloat() / barCount) <= progress
            val color = if (isPlayed) activeColor else inactiveColor

            drawLine(
                color = color,
                start = Offset(x, yStart),
                end = Offset(x, yEnd),
                strokeWidth = barWidth,
                cap = StrokeCap.Round
            )
        }
    }
}
