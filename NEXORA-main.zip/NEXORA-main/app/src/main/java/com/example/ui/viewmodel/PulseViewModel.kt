package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.example.data.repository.PulseRepository
import com.example.ui.theme.AppThemeMode
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class MainTab {
    CHATS,    // WhatsApp DMs & Groups
    SERVERS,  // Discord Servers & Channels
    STATUS,   // WhatsApp 24h Status Stories
    CALLS,    // Voice/Video Call logs & Instant Call
    PROFILE   // User Profile & Customization
}

enum class ChatFilter {
    ALL,
    UNREAD,
    GROUPS
}

data class ActiveCallState(
    val callerName: String,
    val callerInitials: String,
    val callerColor: Long,
    val isVideo: Boolean,
    val isConnected: Boolean = true,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = true,
    val isCameraOn: Boolean = true,
    val durationSeconds: Int = 0
)

data class ActiveVoiceRoomState(
    val channelId: String,
    val channelName: String,
    val serverName: String,
    val isConnected: Boolean = true,
    val isMuted: Boolean = false,
    val isDeafened: Boolean = false,
    val isCameraOn: Boolean = false,
    val isScreenSharing: Boolean = false,
    val participants: List<VoiceParticipant> = emptyList(),
    val activeSoundEffect: String? = null
)

class PulseViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PulseRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = PulseRepository(database.pulseDao())
    }

    // Navigation & Main State
    private val _currentTab = MutableStateFlow(MainTab.CHATS)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _themeMode = MutableStateFlow(AppThemeMode.DISCORD)
    val themeMode: StateFlow<AppThemeMode> = _themeMode.asStateFlow()

    private val _userStatus = MutableStateFlow(UserPresence.ONLINE)
    val userStatus: StateFlow<UserPresence> = _userStatus.asStateFlow()

    private val _customStatusText = MutableStateFlow("Coding in Jetpack Compose 🚀")
    val customStatusText: StateFlow<String> = _customStatusText.asStateFlow()

    // Chats
    val allChats: StateFlow<List<Chat>> = repository.getAllChats()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _chatFilter = MutableStateFlow(ChatFilter.ALL)
    val chatFilter: StateFlow<ChatFilter> = _chatFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val filteredChats: StateFlow<List<Chat>> = combine(allChats, _chatFilter, _searchQuery) { chats, filter, query ->
        chats.filter { chat ->
            val matchesFilter = when (filter) {
                ChatFilter.ALL -> true
                ChatFilter.UNREAD -> chat.unreadCount > 0
                ChatFilter.GROUPS -> chat.isGroup
            }
            val matchesQuery = query.isBlank() || chat.name.contains(query, ignoreCase = true) || chat.lastMessage.contains(query, ignoreCase = true)
            matchesFilter && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Open Conversation (Chat or Channel)
    private val _activeConversation = MutableStateFlow<ActiveConversation?>(null)
    val activeConversation: StateFlow<ActiveConversation?> = _activeConversation.asStateFlow()

    // Messages for active conversation
    private val _activeMessages = MutableStateFlow<List<Message>>(emptyList())
    val activeMessages: StateFlow<List<Message>> = _activeMessages.asStateFlow()

    private var messagesJob: Job? = null

    // Discord Servers & Channels
    val allServers: StateFlow<List<Server>> = repository.getAllServers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedServerId = MutableStateFlow<String?>("srv_dev_sanctuary")
    val selectedServerId: StateFlow<String?> = _selectedServerId.asStateFlow()

    val currentServerChannels: StateFlow<List<Channel>> = _selectedServerId.flatMapLatest { serverId ->
        if (serverId != null) repository.getChannelsForServer(serverId) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Status Stories (WhatsApp style)
    val allStories: StateFlow<List<StatusStory>> = repository.getAllStories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeStory = MutableStateFlow<StatusStory?>(null)
    val activeStory: StateFlow<StatusStory?> = _activeStory.asStateFlow()

    // Calls
    val callLogs: StateFlow<List<CallLog>> = repository.getAllCallLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeCall = MutableStateFlow<ActiveCallState?>(null)
    val activeCall: StateFlow<ActiveCallState?> = _activeCall.asStateFlow()
    private var callTimerJob: Job? = null

    // Discord Voice Channel Room
    private val _activeVoiceRoom = MutableStateFlow<ActiveVoiceRoomState?>(null)
    val activeVoiceRoom: StateFlow<ActiveVoiceRoomState?> = _activeVoiceRoom.asStateFlow()
    private var voiceSimulationJob: Job? = null

    // Reply and Audio recording state
    private val _replyingToMessage = MutableStateFlow<Message?>(null)
    val replyingToMessage: StateFlow<Message?> = _replyingToMessage.asStateFlow()

    // Actions
    fun setTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun setTheme(theme: AppThemeMode) {
        _themeMode.value = theme
    }

    fun setUserStatus(status: UserPresence) {
        _userStatus.value = status
    }

    fun setCustomStatusText(text: String) {
        _customStatusText.value = text
    }

    fun setChatFilter(filter: ChatFilter) {
        _chatFilter.value = filter
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectServer(serverId: String) {
        _selectedServerId.value = serverId
    }

    fun openChat(chat: Chat) {
        _activeConversation.value = ActiveConversation(
            id = chat.id,
            title = chat.name,
            subtitle = if (chat.isGroup) "Group • 14 members" else if (chat.contactStatus == UserPresence.ONLINE) "Online" else "Last seen recently",
            isChannel = false,
            initials = chat.initials,
            color = chat.avatarColor
        )
        loadMessages(chat.id)
    }

    fun openChannel(channel: Channel, serverName: String) {
        if (channel.type == ChannelType.VOICE) {
            joinVoiceChannel(channel, serverName)
            return
        }
        _activeConversation.value = ActiveConversation(
            id = channel.id,
            title = "#${channel.name}",
            subtitle = if (channel.topic.isNotBlank()) channel.topic else "$serverName • Channel",
            isChannel = true,
            initials = "#",
            color = 0xFF5865F2
        )
        loadMessages(channel.id)
    }

    private fun loadMessages(conversationId: String) {
        messagesJob?.cancel()
        messagesJob = viewModelScope.launch {
            repository.getMessages(conversationId).collect {
                _activeMessages.value = it
            }
        }
    }

    fun closeConversation() {
        _activeConversation.value = null
        messagesJob?.cancel()
        _replyingToMessage.value = null
    }

    fun sendMessage(
        content: String,
        type: MessageType = MessageType.TEXT,
        voiceDurationSec: Int = 0,
        mediaUri: String? = null,
        codeLanguage: String? = null
    ) {
        val conv = _activeConversation.value ?: return
        if (content.isBlank() && type == MessageType.TEXT) return

        viewModelScope.launch {
            repository.sendMessage(
                conversationId = conv.id,
                content = content,
                type = type,
                voiceDurationSec = voiceDurationSec,
                mediaUri = mediaUri,
                codeLanguage = codeLanguage,
                replyToMessage = _replyingToMessage.value
            )
            _replyingToMessage.value = null
        }
    }

    fun setReplyingTo(message: Message?) {
        _replyingToMessage.value = message
    }

    fun toggleReaction(messageId: String, currentReactions: Map<String, Int>, emoji: String) {
        viewModelScope.launch {
            repository.toggleReaction(messageId, currentReactions, emoji)
        }
    }

    fun togglePinMessage(messageId: String, isPinned: Boolean) {
        viewModelScope.launch {
            repository.togglePin(messageId, isPinned)
        }
    }

    fun deleteMessage(messageId: String) {
        viewModelScope.launch {
            repository.deleteMessage(messageId)
        }
    }

    fun createNewChat(name: String, isGroup: Boolean) {
        viewModelScope.launch {
            val id = repository.createChat(name, isGroup)
            val chat = Chat(
                id = id,
                name = name,
                isGroup = isGroup,
                avatarColor = if (isGroup) 0xFF5865F2 else 0xFF25D366,
                initials = name.take(2).uppercase()
            )
            openChat(chat)
        }
    }

    fun createServer(name: String, desc: String) {
        viewModelScope.launch {
            val serverId = repository.createServer(name, desc)
            _selectedServerId.value = serverId
        }
    }

    fun createChannel(name: String, type: ChannelType, category: String) {
        val serverId = _selectedServerId.value ?: return
        viewModelScope.launch {
            repository.createChannel(serverId, name, type, category)
        }
    }

    // WhatsApp Status Stories
    fun openStory(story: StatusStory) {
        _activeStory.value = story
        viewModelScope.launch {
            repository.markStoryViewed(story.id)
        }
    }

    fun closeStory() {
        _activeStory.value = null
    }

    fun postStatusStory(text: String, bgColorHex: Long) {
        viewModelScope.launch {
            repository.postStatusStory(text, bgColorHex)
        }
    }

    // 1-on-1 Audio/Video Call
    fun startCall(callerName: String, initials: String, color: Long, isVideo: Boolean) {
        _activeCall.value = ActiveCallState(
            callerName = callerName,
            callerInitials = initials,
            callerColor = color,
            isVideo = isVideo,
            isConnected = true,
            durationSeconds = 0
        )
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _activeCall.update { current ->
                    current?.copy(durationSeconds = current.durationSeconds + 1)
                }
            }
        }
    }

    fun toggleCallMute() {
        _activeCall.update { it?.copy(isMuted = !it.isMuted) }
    }

    fun toggleCallSpeaker() {
        _activeCall.update { it?.copy(isSpeakerOn = !it.isSpeakerOn) }
    }

    fun toggleCallCamera() {
        _activeCall.update { it?.copy(isCameraOn = !it.isCameraOn) }
    }

    fun endCall() {
        val call = _activeCall.value
        callTimerJob?.cancel()
        if (call != null) {
            val mins = call.durationSeconds / 60
            val secs = call.durationSeconds % 60
            val durationText = "${mins}m ${secs}s"
            viewModelScope.launch {
                repository.recordCall(call.callerName, call.isVideo, durationText)
            }
        }
        _activeCall.value = null
    }

    // Discord Voice Lounge / Channel
    fun joinVoiceChannel(channel: Channel, serverName: String) {
        val initialParticipants = listOf(
            VoiceParticipant("p_me", "You", "ME", 0xFF5865F2, isSpeaking = false),
            VoiceParticipant("p_alex", "Alex Rivers", "AR", 0xFF25D366, isSpeaking = true),
            VoiceParticipant("p_sarah", "Sarah Chen", "SC", 0xFFEB459E, isSpeaking = false),
            VoiceParticipant("p_marcus", "Marcus [Lead]", "MK", 0xFFFEE75C, isSpeaking = false)
        )

        _activeVoiceRoom.value = ActiveVoiceRoomState(
            channelId = channel.id,
            channelName = channel.name,
            serverName = serverName,
            isConnected = true,
            participants = initialParticipants
        )

        startVoiceSimulation()
    }

    private fun startVoiceSimulation() {
        voiceSimulationJob?.cancel()
        voiceSimulationJob = viewModelScope.launch {
            var counter = 0
            while (true) {
                delay(2200)
                counter++
                _activeVoiceRoom.update { current ->
                    if (current == null) return@update null
                    val updatedParticipants = current.participants.mapIndexed { index, participant ->
                        if (participant.id == "p_me") participant
                        else {
                            val shouldSpeak = (index + counter) % 3 == 0
                            participant.copy(isSpeaking = shouldSpeak)
                        }
                    }
                    current.copy(participants = updatedParticipants)
                }
            }
        }
    }

    fun toggleVoiceMute() {
        _activeVoiceRoom.update { current ->
            if (current == null) return@update null
            val newMute = !current.isMuted
            val updatedParticipants = current.participants.map {
                if (it.id == "p_me") it.copy(isMuted = newMute, isSpeaking = if (newMute) false else it.isSpeaking) else it
            }
            current.copy(isMuted = newMute, participants = updatedParticipants)
        }
    }

    fun toggleVoiceDeafen() {
        _activeVoiceRoom.update { current ->
            if (current == null) return@update null
            val newDeafen = !current.isDeafened
            val newMute = if (newDeafen) true else current.isMuted
            val updatedParticipants = current.participants.map {
                if (it.id == "p_me") it.copy(isDeafened = newDeafen, isMuted = newMute) else it
            }
            current.copy(isDeafened = newDeafen, isMuted = newMute, participants = updatedParticipants)
        }
    }

    fun toggleVoiceCamera() {
        _activeVoiceRoom.update { current ->
            if (current == null) return@update null
            val newCamera = !current.isCameraOn
            val updatedParticipants = current.participants.map {
                if (it.id == "p_me") it.copy(isCameraOn = newCamera) else it
            }
            current.copy(isCameraOn = newCamera, participants = updatedParticipants)
        }
    }

    fun toggleVoiceScreenShare() {
        _activeVoiceRoom.update { current ->
            if (current == null) return@update null
            val newShare = !current.isScreenSharing
            val updatedParticipants = current.participants.map {
                if (it.id == "p_me") it.copy(isScreenSharing = newShare) else it
            }
            current.copy(isScreenSharing = newShare, participants = updatedParticipants)
        }
    }

    fun triggerSoundboardEffect(soundName: String) {
        viewModelScope.launch {
            _activeVoiceRoom.update { it?.copy(activeSoundEffect = soundName) }
            delay(1800)
            _activeVoiceRoom.update { it?.copy(activeSoundEffect = null) }
        }
    }

    fun disconnectVoice() {
        voiceSimulationJob?.cancel()
        _activeVoiceRoom.value = null
    }
}

data class ActiveConversation(
    val id: String,
    val title: String,
    val subtitle: String,
    val isChannel: Boolean,
    val initials: String,
    val color: Long
)
