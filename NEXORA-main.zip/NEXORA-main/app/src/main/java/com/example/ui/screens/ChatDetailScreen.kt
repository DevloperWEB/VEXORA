package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Message
import com.example.data.model.MessageType
import com.example.ui.components.AudioWaveform
import com.example.ui.components.MessageDeliveryIcon
import com.example.ui.components.UserAvatar
import com.example.ui.theme.*
import com.example.ui.viewmodel.ActiveConversation
import com.example.ui.viewmodel.PulseViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
    conversation: ActiveConversation,
    viewModel: PulseViewModel,
    modifier: Modifier = Modifier
) {
    val messages by viewModel.activeMessages.collectAsState()
    val replyingTo by viewModel.replyingToMessage.collectAsState()

    var inputText by remember { mutableStateOf("") }
    var isRecordingAudio by remember { mutableStateOf(false) }
    var recordingTimer by remember { mutableIntStateOf(0) }

    var showAttachDialog by remember { mutableStateOf(false) }
    var showCodeDialog by remember { mutableStateOf(false) }
    var selectedMessageForMenu by remember { mutableStateOf<Message?>(null) }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    // Auto-scroll on new message
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Timer for audio recording simulation
    LaunchedEffect(isRecordingAudio) {
        if (isRecordingAudio) {
            recordingTimer = 0
            while (isRecordingAudio) {
                delay(1000)
                recordingTimer++
            }
        }
    }

    BackHandler {
        viewModel.closeConversation()
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        UserAvatar(
                            initials = conversation.initials,
                            backgroundColor = conversation.color,
                            size = 38.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = conversation.title,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = conversation.subtitle,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.closeConversation() },
                        modifier = Modifier.testTag("chat_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    if (!conversation.isChannel) {
                        IconButton(
                            onClick = {
                                viewModel.startCall(
                                    callerName = conversation.title,
                                    initials = conversation.initials,
                                    color = conversation.color,
                                    isVideo = false
                                )
                            },
                            modifier = Modifier.testTag("action_voice_call")
                        ) {
                            Icon(imageVector = Icons.Default.Call, contentDescription = "Voice Call")
                        }
                        IconButton(
                            onClick = {
                                viewModel.startCall(
                                    callerName = conversation.title,
                                    initials = conversation.initials,
                                    color = conversation.color,
                                    isVideo = true
                                )
                            },
                            modifier = Modifier.testTag("action_video_call")
                        ) {
                            Icon(imageVector = Icons.Default.Videocam, contentDescription = "Video Call")
                        }
                    } else {
                        IconButton(onClick = { showCodeDialog = true }) {
                            Icon(imageVector = Icons.Default.Code, contentDescription = "Share Code")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
            ) {
                // Reply preview bar
                AnimatedVisibility(visible = replyingTo != null) {
                    if (replyingTo != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Reply,
                                        contentDescription = "Replying",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "Replying to ${replyingTo!!.senderName}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = replyingTo!!.content,
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                IconButton(onClick = { viewModel.setReplyingTo(null) }) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Cancel reply",
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Input Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isRecordingAudio) {
                        // Live voice recording UI
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(24.dp))
                                .background(DiscordRed.copy(alpha = 0.15f))
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(DiscordRed)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Recording: ${recordingTimer}s",
                                color = DiscordRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = "Tap cancel or send",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        }

                        IconButton(
                            onClick = { isRecordingAudio = false },
                            modifier = Modifier.testTag("btn_cancel_voice_recording")
                        ) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = "Cancel", tint = DiscordRed)
                        }

                        IconButton(
                            onClick = {
                                val duration = recordingTimer.coerceAtLeast(3)
                                viewModel.sendMessage(
                                    content = "Voice message",
                                    type = MessageType.VOICE_NOTE,
                                    voiceDurationSec = duration
                                )
                                isRecordingAudio = false
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(WhatsAppGreen)
                                .testTag("btn_send_voice_note")
                        ) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = "Send voice note", tint = Color.Black)
                        }
                    } else {
                        // Standard Message Composer
                        IconButton(
                            onClick = { showAttachDialog = true },
                            modifier = Modifier.testTag("btn_attach")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Attach",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = {
                                Text(
                                    if (conversation.isChannel) "Message ${conversation.title}" else "Type a message...",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 14.sp
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_input_field"),
                            shape = RoundedCornerShape(24.dp),
                            maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent,
                                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        )

                        Spacer(modifier = Modifier.width(4.dp))

                        if (inputText.isBlank()) {
                            // Voice note trigger button
                            IconButton(
                                onClick = { isRecordingAudio = true },
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                                    .testTag("btn_record_voice")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Record Voice Note",
                                    tint = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        } else {
                            // Send text button
                            IconButton(
                                onClick = {
                                    val text = inputText.trim()
                                    if (text.isNotEmpty()) {
                                        viewModel.sendMessage(text)
                                        inputText = ""
                                    }
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary)
                                    .testTag("btn_send_message")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Send",
                                    tint = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(
                    if (conversation.isChannel) DiscordDarker else MaterialTheme.colorScheme.background
                )
        ) {
            // Pinned message banner if any
            val pinnedMessage = remember(messages) { messages.find { it.isPinned } }
            if (pinnedMessage != null) {
                Surface(
                    color = DiscordBlurple.copy(alpha = 0.15f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.PushPin,
                            contentDescription = "Pinned",
                            tint = DiscordBlurple,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Pinned: ${pinnedMessage.senderName}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = DiscordBlurple
                            )
                            Text(
                                text = pinnedMessage.content,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // Message list
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                contentPadding = PaddingValues(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    if (conversation.isChannel) {
                        DiscordMessageItem(
                            message = message,
                            onLongClick = { selectedMessageForMenu = message },
                            onReaction = { emoji ->
                                viewModel.toggleReaction(message.id, message.reactions, emoji)
                            }
                        )
                    } else {
                        WhatsAppMessageBubble(
                            message = message,
                            onLongClick = { selectedMessageForMenu = message },
                            onReaction = { emoji ->
                                viewModel.toggleReaction(message.id, message.reactions, emoji)
                            }
                        )
                    }
                }
            }
        }
    }

    // Message options bottom sheet / dialog
    if (selectedMessageForMenu != null) {
        val msg = selectedMessageForMenu!!
        AlertDialog(
            onDismissRequest = { selectedMessageForMenu = null },
            title = { Text("Message Options") },
            text = {
                Column {
                    // Quick emoji reactions
                    Row(
                        horizontalArrangement = Arrangement.SpaceAround,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        listOf("❤️", "🔥", "👍", "😂", "🎉", "💯").forEach { emoji ->
                            Text(
                                text = emoji,
                                fontSize = 24.sp,
                                modifier = Modifier
                                    .clickable {
                                        viewModel.toggleReaction(msg.id, msg.reactions, emoji)
                                        selectedMessageForMenu = null
                                    }
                                    .padding(4.dp)
                            )
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    ListItem(
                        headlineContent = { Text("Reply") },
                        leadingContent = { Icon(Icons.AutoMirrored.Filled.Reply, null) },
                        modifier = Modifier.clickable {
                            viewModel.setReplyingTo(msg)
                            selectedMessageForMenu = null
                        }
                    )
                    ListItem(
                        headlineContent = { Text(if (msg.isPinned) "Unpin Message" else "Pin Message") },
                        leadingContent = { Icon(Icons.Default.PushPin, null) },
                        modifier = Modifier.clickable {
                            viewModel.togglePinMessage(msg.id, msg.isPinned)
                            selectedMessageForMenu = null
                        }
                    )
                    ListItem(
                        headlineContent = { Text("Copy Text") },
                        leadingContent = { Icon(Icons.Default.ContentCopy, null) },
                        modifier = Modifier.clickable {
                            clipboardManager.setText(AnnotatedString(msg.content))
                            Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                            selectedMessageForMenu = null
                        }
                    )
                    if (msg.isFromMe) {
                        ListItem(
                            headlineContent = { Text("Delete", color = DiscordRed) },
                            leadingContent = { Icon(Icons.Default.Delete, null, tint = DiscordRed) },
                            modifier = Modifier.clickable {
                                viewModel.deleteMessage(msg.id)
                                selectedMessageForMenu = null
                            }
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { selectedMessageForMenu = null }) {
                    Text("Close")
                }
            }
        )
    }

    // Attachment Chooser Dialog
    if (showAttachDialog) {
        AlertDialog(
            onDismissRequest = { showAttachDialog = false },
            title = { Text("Share Content") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ListItem(
                        headlineContent = { Text("Share Code Snippet") },
                        supportingContent = { Text("Syntax highlighted Kotlin, JS, etc.") },
                        leadingContent = { Icon(Icons.Default.Code, null, tint = DiscordBlurple) },
                        modifier = Modifier.clickable {
                            showAttachDialog = false
                            showCodeDialog = true
                        }
                    )
                    ListItem(
                        headlineContent = { Text("Send Photo") },
                        supportingContent = { Text("Attach screenshot or project photo") },
                        leadingContent = { Icon(Icons.Default.Image, null, tint = WhatsAppGreen) },
                        modifier = Modifier.clickable {
                            viewModel.sendMessage(
                                content = "Shared project asset",
                                type = MessageType.IMAGE,
                                mediaUri = "sample_media"
                            )
                            showAttachDialog = false
                        }
                    )
                    ListItem(
                        headlineContent = { Text("Record Voice Note") },
                        supportingContent = { Text("Record up to 60s voice message") },
                        leadingContent = { Icon(Icons.Default.Mic, null, tint = PulseNeonViolet) },
                        modifier = Modifier.clickable {
                            showAttachDialog = false
                            isRecordingAudio = true
                        }
                    )
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showAttachDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Code Snippet Share Dialog
    if (showCodeDialog) {
        var codeContent by remember { mutableStateOf("fun main() {\n    println(\"Hello from Pulse! WhatsApp + Discord Unified 🚀\")\n}") }
        var language by remember { mutableStateOf("Kotlin") }

        AlertDialog(
            onDismissRequest = { showCodeDialog = false },
            title = { Text("Share Code Snippet") },
            text = {
                Column {
                    OutlinedTextField(
                        value = language,
                        onValueChange = { language = it },
                        label = { Text("Language") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = codeContent,
                        onValueChange = { codeContent = it },
                        label = { Text("Code") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (codeContent.isNotBlank()) {
                            viewModel.sendMessage(
                                content = codeContent.trim(),
                                type = MessageType.CODE,
                                codeLanguage = language
                            )
                            showCodeDialog = false
                        }
                    }
                ) {
                    Text("Post Code")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCodeDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun WhatsAppMessageBubble(
    message: Message,
    onLongClick: () -> Unit,
    onReaction: (String) -> Unit
) {
    val timeFormat = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    val formattedTime = remember(message.timestamp) { timeFormat.format(Date(message.timestamp)) }

    val bubbleColor = if (message.isFromMe) WhatsAppOutgoingBubble else WhatsAppIncomingBubble
    val alignment = if (message.isFromMe) Alignment.End else Alignment.Start

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment
    ) {
        Surface(
            color = bubbleColor,
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (message.isFromMe) 16.dp else 4.dp,
                bottomEnd = if (message.isFromMe) 4.dp else 16.dp
            ),
            modifier = Modifier
                .widthIn(max = 310.dp)
                .clickable { onLongClick() }
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                // Reply quote if any
                if (message.replyToAuthor != null) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                    ) {
                        Row(modifier = Modifier.padding(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(28.dp)
                                    .background(WhatsAppGreen)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = message.replyToAuthor,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = WhatsAppGreen
                                )
                                Text(
                                    text = message.replyToContent ?: "",
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }

                // Message Content by Type
                when (message.type) {
                    MessageType.VOICE_NOTE -> {
                        VoiceNotePlayer(
                            durationSec = message.voiceDurationSec,
                            accentColor = if (message.isFromMe) Color.White else WhatsAppTickBlue
                        )
                    }
                    MessageType.CODE -> {
                        CodeMessageBlock(
                            code = message.content,
                            language = message.codeLanguage ?: "Code"
                        )
                    }
                    MessageType.IMAGE -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1E242B)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = "Photo",
                                tint = WhatsAppGreen,
                                modifier = Modifier.size(48.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = message.content, color = Color.White, fontSize = 14.sp)
                    }
                    else -> {
                        Text(
                            text = message.content,
                            color = Color.White,
                            fontSize = 15.sp,
                            lineHeight = 20.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Time and delivery status
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = formattedTime,
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                    if (message.isFromMe) {
                        Spacer(modifier = Modifier.width(4.dp))
                        MessageDeliveryIcon(status = message.status)
                    }
                }
            }
        }

        // Reactions badges
        if (message.reactions.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .padding(top = 2.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black.copy(alpha = 0.3f))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                message.reactions.forEach { (emoji, count) ->
                    Text(
                        text = "$emoji $count",
                        fontSize = 12.sp,
                        color = Color.White,
                        modifier = Modifier.clickable { onReaction(emoji) }
                    )
                }
            }
        }
    }
}

@Composable
fun DiscordMessageItem(
    message: Message,
    onLongClick: () -> Unit,
    onReaction: (String) -> Unit
) {
    val timeFormat = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    val formattedTime = remember(message.timestamp) { timeFormat.format(Date(message.timestamp)) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onLongClick() }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        UserAvatar(
            initials = message.senderName.take(2).uppercase(),
            backgroundColor = message.senderColor,
            size = 40.dp
        )

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = message.senderName,
                    color = Color(message.senderColor),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = formattedTime,
                    color = DiscordTextSecondary,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            when (message.type) {
                MessageType.VOICE_NOTE -> {
                    VoiceNotePlayer(durationSec = message.voiceDurationSec, accentColor = DiscordGreen)
                }
                MessageType.CODE -> {
                    CodeMessageBlock(code = message.content, language = message.codeLanguage ?: "Kotlin")
                }
                MessageType.SYSTEM -> {
                    Surface(
                        color = DiscordCard,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = message.content,
                            color = DiscordYellow,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
                else -> {
                    Text(
                        text = message.content,
                        color = DiscordTextPrimary,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                }
            }

            // Reactions badges
            if (message.reactions.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    message.reactions.forEach { (emoji, count) ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = DiscordCard,
                            border = androidx.compose.foundation.BorderStroke(1.dp, DiscordBlurple.copy(alpha = 0.4f)),
                            modifier = Modifier.clickable { onReaction(emoji) }
                        ) {
                            Text(
                                text = "$emoji $count",
                                fontSize = 12.sp,
                                color = DiscordTextPrimary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VoiceNotePlayer(
    durationSec: Int,
    accentColor: Color
) {
    var isPlaying by remember { mutableStateOf(false) }
    var playbackProgress by remember { mutableFloatStateOf(0f) }
    var speed by remember { mutableFloatStateOf(1f) }

    LaunchedEffect(isPlaying, speed) {
        if (isPlaying) {
            val totalMillis = (durationSec * 1000L / speed).toLong()
            val stepMillis = 100L
            val stepFraction = stepMillis.toFloat() / totalMillis

            while (isPlaying && playbackProgress < 1f) {
                delay(stepMillis)
                playbackProgress = (playbackProgress + stepFraction).coerceAtMost(1f)
            }
            if (playbackProgress >= 1f) {
                isPlaying = false
                playbackProgress = 0f
            }
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = { isPlaying = !isPlaying },
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.2f))
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                tint = accentColor,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Column(modifier = Modifier.weight(1f)) {
            AudioWaveform(
                isPlaying = isPlaying,
                progress = playbackProgress,
                activeColor = accentColor,
                modifier = Modifier.fillMaxWidth()
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${((1f - playbackProgress) * durationSec).toInt()}s",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.6f)
                )
            }
        }

        Spacer(modifier = Modifier.width(6.dp))

        // Speed pill (1x, 1.5x, 2x)
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White.copy(alpha = 0.15f),
            modifier = Modifier.clickable {
                speed = when (speed) {
                    1f -> 1.5f
                    1.5f -> 2f
                    else -> 1f
                }
            }
        ) {
            Text(
                text = "${speed}x",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}

@Composable
fun CodeMessageBlock(
    code: String,
    language: String
) {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current

    Surface(
        color = Color(0xFF1E1F22),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2B2D31)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF2B2D31))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = language.uppercase(),
                    color = DiscordTextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = {
                        clipboard.setText(AnnotatedString(code))
                        Toast.makeText(context, "Code copied!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy code",
                        tint = DiscordTextSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Text(
                text = code,
                color = Color(0xFFE3E5E8),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 16.sp,
                modifier = Modifier.padding(10.dp)
            )
        }
    }
}
