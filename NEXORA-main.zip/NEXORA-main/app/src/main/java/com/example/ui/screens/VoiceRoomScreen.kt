package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VoiceParticipant
import com.example.ui.components.UserAvatar
import com.example.ui.theme.*
import com.example.ui.viewmodel.ActiveVoiceRoomState
import com.example.ui.viewmodel.PulseViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceRoomScreen(
    voiceState: ActiveVoiceRoomState,
    viewModel: PulseViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showSoundboard by remember { mutableStateOf(false) }

    BackHandler {
        onBack()
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(DiscordDarker),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = null,
                                tint = DiscordGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = voiceState.channelName,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Text(
                            text = "${voiceState.serverName} • ${voiceState.participants.size} Connected",
                            fontSize = 12.sp,
                            color = DiscordTextSecondary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("voice_room_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Minimize",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showSoundboard = !showSoundboard },
                        modifier = Modifier.testTag("action_toggle_soundboard")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = "Soundboard",
                            tint = if (showSoundboard) DiscordYellow else Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DiscordDark
                )
            )
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DiscordDark)
                    .padding(vertical = 12.dp, horizontal = 16.dp)
            ) {
                // Soundboard Drawer if opened
                AnimatedVisibility(visible = showSoundboard) {
                    SoundboardPanel(
                        onPlaySound = { sound ->
                            viewModel.triggerSoundboardEffect(sound)
                        }
                    )
                }

                // Active sound effect indicator
                if (voiceState.activeSoundEffect != null) {
                    Surface(
                        color = DiscordYellow.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                    ) {
                        Text(
                            text = "🔊 Soundboard: ${voiceState.activeSoundEffect}!",
                            color = DiscordYellow,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }

                // Controls Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Video Camera
                    IconButton(
                        onClick = { viewModel.toggleVoiceCamera() },
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(if (voiceState.isCameraOn) DiscordGreen else DiscordCard)
                            .testTag("voice_camera_btn")
                    ) {
                        Icon(
                            imageVector = if (voiceState.isCameraOn) Icons.Default.Videocam else Icons.Default.VideocamOff,
                            contentDescription = "Camera",
                            tint = if (voiceState.isCameraOn) Color.Black else Color.White
                        )
                    }

                    // Screen Share
                    IconButton(
                        onClick = { viewModel.toggleVoiceScreenShare() },
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(if (voiceState.isScreenSharing) DiscordBlurple else DiscordCard)
                            .testTag("voice_screenshare_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ScreenShare,
                            contentDescription = "Screen Share",
                            tint = Color.White
                        )
                    }

                    // Mute / Unmute
                    IconButton(
                        onClick = { viewModel.toggleVoiceMute() },
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(if (voiceState.isMuted) DiscordRed else DiscordCard)
                            .testTag("voice_mute_btn")
                    ) {
                        Icon(
                            imageVector = if (voiceState.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Mute",
                            tint = Color.White
                        )
                    }

                    // Deafen
                    IconButton(
                        onClick = { viewModel.toggleVoiceDeafen() },
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(if (voiceState.isDeafened) DiscordRed else DiscordCard)
                            .testTag("voice_deafen_btn")
                    ) {
                        Icon(
                            imageVector = if (voiceState.isDeafened) Icons.Default.HeadsetOff else Icons.Default.Headset,
                            contentDescription = "Deafen",
                            tint = Color.White
                        )
                    }

                    // Disconnect
                    IconButton(
                        onClick = {
                            viewModel.disconnectVoice()
                            onBack()
                        },
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(DiscordRed)
                            .testTag("voice_disconnect_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CallEnd,
                            contentDescription = "Disconnect",
                            tint = Color.White
                        )
                    }
                }
            }
        },
        containerColor = DiscordDarker
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(voiceState.participants, key = { it.id }) { participant ->
                VoiceParticipantCard(participant = participant)
            }
        }
    }
}

@Composable
fun VoiceParticipantCard(participant: VoiceParticipant) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DiscordCard),
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .then(
                if (participant.isSpeaking) {
                    Modifier.border(2.5.dp, DiscordGreen, RoundedCornerShape(16.dp))
                } else Modifier
            )
            .testTag("voice_tile_${participant.id}")
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (participant.isCameraOn) {
                // Simulated camera feed
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF1E293B)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("📷 Live Camera Stream", color = Color.White, fontSize = 12.sp)
                }
            } else if (participant.isScreenSharing) {
                // Simulated screen share
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0F172A)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.ScreenShare, contentDescription = null, tint = DiscordBlurple)
                        Text("🖥️ Screen Sharing", color = Color.White, fontSize = 12.sp)
                    }
                }
            } else {
                // Avatar view with speaking wave
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    UserAvatar(
                        initials = participant.initials,
                        backgroundColor = participant.avatarColor,
                        size = 64.dp,
                        isSpeaking = participant.isSpeaking
                    )
                }
            }

            // Name & Status chip at bottom
            Surface(
                color = Color.Black.copy(alpha = 0.6f),
                shape = RoundedCornerShape(topEnd = 10.dp),
                modifier = Modifier.align(Alignment.BottomStart)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = participant.name,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )

                    if (participant.isMuted) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.MicOff,
                            contentDescription = "Muted",
                            tint = DiscordRed,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SoundboardPanel(
    onPlaySound: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DiscordSurface),
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "DISCORD SOUNDBOARD",
                color = DiscordTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            val sounds = listOf(
                "🎺 Airhorn" to "Airhorn",
                "🎮 GG" to "GG",
                "👏 Applause" to "Applause",
                "🥁 Ba-Dum-Tss" to "Ba-Dum-Tss",
                "🦆 Quack" to "Quack",
                "🔔 Ding" to "Ding"
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                sounds.take(3).forEach { (label, name) ->
                    Button(
                        onClick = { onPlaySound(name) },
                        colors = ButtonDefaults.buttonColors(containerColor = DiscordCard),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).testTag("sound_$name")
                    ) {
                        Text(label, fontSize = 11.sp, maxLines = 1)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                sounds.drop(3).forEach { (label, name) ->
                    Button(
                        onClick = { onPlaySound(name) },
                        colors = ButtonDefaults.buttonColors(containerColor = DiscordCard),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).testTag("sound_$name")
                    ) {
                        Text(label, fontSize = 11.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}
