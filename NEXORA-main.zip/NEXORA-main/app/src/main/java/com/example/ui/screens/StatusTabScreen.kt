package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StatusStory
import com.example.ui.components.UserAvatar
import com.example.ui.theme.*
import com.example.ui.viewmodel.PulseViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun StatusTabScreen(
    viewModel: PulseViewModel,
    modifier: Modifier = Modifier
) {
    val stories by viewModel.allStories.collectAsState()

    val myStory = remember(stories) { stories.find { it.isMine } }
    val friendStories = remember(stories) { stories.filter { !it.isMine } }
    val recentStories = remember(friendStories) { friendStories.filter { !it.isViewed } }
    val viewedStories = remember(friendStories) { friendStories.filter { it.isViewed } }

    var showCreateTextStatusDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Secondary Text Status button (WhatsApp pencil)
                SmallFloatingActionButton(
                    onClick = { showCreateTextStatusDialog = true },
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    shape = CircleShape,
                    modifier = Modifier.testTag("fab_text_status")
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Text Status",
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Primary Photo / Update button
                FloatingActionButton(
                    onClick = { showCreateTextStatusDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    shape = CircleShape,
                    modifier = Modifier.testTag("fab_camera_status")
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = "New Status",
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        },
        containerColor = Color.Transparent
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // My Status Section
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            if (myStory != null) {
                                viewModel.openStory(myStory)
                            } else {
                                showCreateTextStatusDialog = true
                            }
                        }
                        .padding(vertical = 8.dp)
                        .testTag("my_status_row"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.size(56.dp)) {
                        UserAvatar(
                            initials = "ME",
                            backgroundColor = 0xFF005C4B,
                            size = 56.dp,
                            modifier = if (myStory != null) {
                                Modifier.border(2.5.dp, WhatsAppGreen, CircleShape)
                            } else Modifier
                        )

                        if (myStory == null) {
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .align(Alignment.BottomEnd)
                                    .clip(CircleShape)
                                    .background(WhatsAppGreen)
                                    .border(2.dp, MaterialTheme.colorScheme.background, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Add",
                                    tint = Color.Black,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "My Status",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (myStory != null) "Tap to view • ${myStory.viewCount} views" else "Tap to add status update",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    }

                    if (myStory != null) {
                        IconButton(onClick = { showCreateTextStatusDialog = true }) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Add more",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Recent Updates
            if (recentStories.isNotEmpty()) {
                item {
                    Text(
                        text = "RECENT UPDATES",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }

                items(recentStories, key = { it.id }) { story ->
                    StatusStoryItemRow(
                        story = story,
                        isViewed = false,
                        onClick = { viewModel.openStory(story) }
                    )
                }

                item { Spacer(modifier = Modifier.height(16.dp)) }
            }

            // Viewed Updates
            if (viewedStories.isNotEmpty()) {
                item {
                    Text(
                        text = "VIEWED UPDATES",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }

                items(viewedStories, key = { it.id }) { story ->
                    StatusStoryItemRow(
                        story = story,
                        isViewed = true,
                        onClick = { viewModel.openStory(story) }
                    )
                }
            }
        }
    }

    if (showCreateTextStatusDialog) {
        CreateTextStatusDialog(
            onDismiss = { showCreateTextStatusDialog = false },
            onPost = { text, colorHex ->
                viewModel.postStatusStory(text, colorHex)
                showCreateTextStatusDialog = false
            }
        )
    }
}

@Composable
fun StatusStoryItemRow(
    story: StatusStory,
    isViewed: Boolean,
    onClick: () -> Unit
) {
    val timeFormat = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    val formattedTime = remember(story.timestamp) { timeFormat.format(Date(story.timestamp)) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 8.dp)
            .testTag("story_${story.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .then(
                    if (!isViewed) Modifier.border(2.5.dp, WhatsAppGreen, CircleShape)
                    else Modifier.border(1.5.dp, Color.Gray.copy(alpha = 0.5f), CircleShape)
                )
                .padding(2.5.dp)
        ) {
            UserAvatar(
                initials = story.userInitials,
                backgroundColor = story.userAvatarColor,
                size = 50.dp
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = story.userName,
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "Today at $formattedTime",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun CreateTextStatusDialog(
    onDismiss: () -> Unit,
    onPost: (text: String, colorHex: Long) -> Unit
) {
    var text by remember { mutableStateOf("") }
    val colors = listOf(
        0xFF005C4B, // WhatsApp Dark Green
        0xFF5865F2, // Discord Blurple
        0xFF9D4EDD, // Cyber Purple
        0xFFEB459E, // Fuchsia
        0xFFED4245, // Crimson Red
        0xFF1F2C34  // Dark Slate
    )
    var selectedColor by remember { mutableStateOf(colors[0]) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Compose Status") },
        text = {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(selectedColor))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (text.isEmpty()) {
                        Text(
                            "Type your status here...",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 16.sp
                        )
                    } else {
                        Text(
                            text = text,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("What's on your mind?") },
                    modifier = Modifier.fillMaxWidth().testTag("status_text_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text("BACKGROUND COLOR", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    colors.forEach { colorHex ->
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color(colorHex))
                                .clickable { selectedColor = colorHex }
                                .then(
                                    if (selectedColor == colorHex) {
                                        Modifier.border(2.5.dp, Color.White, CircleShape)
                                    } else Modifier
                                )
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (text.isNotBlank()) onPost(text.trim(), selectedColor)
                },
                enabled = text.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                modifier = Modifier.testTag("post_status_confirm_button")
            ) {
                Text("Post Status", color = Color.Black)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
