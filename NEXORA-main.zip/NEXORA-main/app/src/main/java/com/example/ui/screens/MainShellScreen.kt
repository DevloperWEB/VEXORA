package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.UserAvatar
import com.example.ui.components.VoiceFloatingBar
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.PulseViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainShellScreen(
    viewModel: PulseViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val allChats by viewModel.allChats.collectAsState()
    val allServers by viewModel.allServers.collectAsState()
    val activeConversation by viewModel.activeConversation.collectAsState()
    val activeVoiceRoom by viewModel.activeVoiceRoom.collectAsState()
    val activeCall by viewModel.activeCall.collectAsState()
    val activeStory by viewModel.activeStory.collectAsState()
    val userStatus by viewModel.userStatus.collectAsState()

    var showVoiceLoungeFullScreen by remember { mutableStateOf(false) }

    val unreadChatsCount = remember(allChats) { allChats.sumOf { it.unreadCount } }
    val serverBadge = remember(allServers) { allServers.any { it.unreadBadge } }

    Box(modifier = modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "NEXORA",
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp,
                                color = MaterialTheme.colorScheme.primary,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = MaterialTheme.shapes.extraSmall,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = when (currentTab) {
                                        MainTab.CHATS -> "WHATSAPP"
                                        MainTab.SERVERS -> "DISCORD"
                                        MainTab.STATUS -> "STORIES"
                                        MainTab.CALLS -> "CALLS"
                                        MainTab.PROFILE -> "PROFILE"
                                    },
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { viewModel.setTab(MainTab.PROFILE) },
                            modifier = Modifier.testTag("top_profile_button")
                        ) {
                            UserAvatar(
                                initials = "ME",
                                backgroundColor = 0xFF5865F2,
                                size = 32.dp,
                                presence = userStatus
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                Column(modifier = Modifier.navigationBarsPadding()) {
                    // Floating Discord Voice Connected bar
                    VoiceFloatingBar(
                        voiceState = activeVoiceRoom,
                        onOpenLounge = { showVoiceLoungeFullScreen = true },
                        onToggleMute = { viewModel.toggleVoiceMute() },
                        onToggleDeafen = { viewModel.toggleVoiceDeafen() },
                        onDisconnect = { viewModel.disconnectVoice() }
                    )

                    // Bottom Navigation Bar
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 8.dp
                    ) {
                        // Chats Tab
                        NavigationBarItem(
                            selected = currentTab == MainTab.CHATS,
                            onClick = { viewModel.setTab(MainTab.CHATS) },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (unreadChatsCount > 0) {
                                            Badge { Text("$unreadChatsCount") }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (currentTab == MainTab.CHATS) Icons.Default.Chat else Icons.Default.ChatBubbleOutline,
                                        contentDescription = "Chats"
                                    )
                                }
                            },
                            label = { Text("Chats") },
                            modifier = Modifier.testTag("tab_chats")
                        )

                        // Discord Servers Tab
                        NavigationBarItem(
                            selected = currentTab == MainTab.SERVERS,
                            onClick = { viewModel.setTab(MainTab.SERVERS) },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (serverBadge) {
                                            Badge()
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (currentTab == MainTab.SERVERS) Icons.Default.Groups else Icons.Default.Group,
                                        contentDescription = "Servers"
                                    )
                                }
                            },
                            label = { Text("Servers") },
                            modifier = Modifier.testTag("tab_servers")
                        )

                        // WhatsApp Status Stories Tab
                        NavigationBarItem(
                            selected = currentTab == MainTab.STATUS,
                            onClick = { viewModel.setTab(MainTab.STATUS) },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == MainTab.STATUS) Icons.Default.DonutLarge else Icons.Default.MotionPhotosOn,
                                    contentDescription = "Status"
                                )
                            },
                            label = { Text("Status") },
                            modifier = Modifier.testTag("tab_status")
                        )

                        // Calls Tab
                        NavigationBarItem(
                            selected = currentTab == MainTab.CALLS,
                            onClick = { viewModel.setTab(MainTab.CALLS) },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == MainTab.CALLS) Icons.Default.Call else Icons.Default.PhoneCallback,
                                    contentDescription = "Calls"
                                )
                            },
                            label = { Text("Calls") },
                            modifier = Modifier.testTag("tab_calls")
                        )

                        // Profile Tab
                        NavigationBarItem(
                            selected = currentTab == MainTab.PROFILE,
                            onClick = { viewModel.setTab(MainTab.PROFILE) },
                            icon = {
                                Icon(
                                    imageVector = if (currentTab == MainTab.PROFILE) Icons.Default.AccountCircle else Icons.Default.PersonOutline,
                                    contentDescription = "Profile"
                                )
                            },
                            label = { Text("Profile") },
                            modifier = Modifier.testTag("tab_profile")
                        )
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                when (currentTab) {
                    MainTab.CHATS -> ChatsTabScreen(viewModel = viewModel)
                    MainTab.SERVERS -> ServersTabScreen(viewModel = viewModel)
                    MainTab.STATUS -> StatusTabScreen(viewModel = viewModel)
                    MainTab.CALLS -> CallsTabScreen(viewModel = viewModel)
                    MainTab.PROFILE -> ProfileTabScreen(viewModel = viewModel)
                }
            }
        }

        // Active Conversation (Direct WhatsApp Chat or Discord Channel)
        AnimatedVisibility(
            visible = activeConversation != null,
            enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
            exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut()
        ) {
            if (activeConversation != null) {
                ChatDetailScreen(
                    conversation = activeConversation!!,
                    viewModel = viewModel
                )
            }
        }

        // Active Voice Lounge (Full-screen Discord Voice room)
        AnimatedVisibility(
            visible = activeVoiceRoom != null && showVoiceLoungeFullScreen,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            if (activeVoiceRoom != null) {
                VoiceRoomScreen(
                    voiceState = activeVoiceRoom!!,
                    viewModel = viewModel,
                    onBack = { showVoiceLoungeFullScreen = false }
                )
            }
        }

        // Active 1-on-1 Call (WhatsApp audio / video call)
        AnimatedVisibility(
            visible = activeCall != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            if (activeCall != null) {
                CallScreen(
                    callState = activeCall!!,
                    viewModel = viewModel
                )
            }
        }

        // Active Status Story Viewer
        AnimatedVisibility(
            visible = activeStory != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            if (activeStory != null) {
                StatusViewerScreen(
                    story = activeStory!!,
                    viewModel = viewModel
                )
            }
        }
    }
}
