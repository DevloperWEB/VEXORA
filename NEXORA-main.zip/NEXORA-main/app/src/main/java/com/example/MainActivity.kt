package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.MainShellScreen
import com.example.ui.theme.PulseAppTheme
import com.example.ui.viewmodel.PulseViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val pulseViewModel: PulseViewModel = viewModel()
            val themeMode by pulseViewModel.themeMode.collectAsState()

            PulseAppTheme(themeMode = themeMode) {
                MainShellScreen(
                    viewModel = pulseViewModel,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
