package com.example.data.model

enum class UserPresence {
    ONLINE,
    IDLE,
    DND,
    OFFLINE
}

data class User(
    val id: String,
    val name: String,
    val username: String,
    val avatarColor: Long = 0xFF5865F2,
    val initials: String = "",
    val status: UserPresence = UserPresence.ONLINE,
    val customStatus: String = "",
    val role: String = "Member",
    val isVerified: Boolean = false,
    val isCurrentUser: Boolean = false
)

enum class MessageType {
    TEXT,
    VOICE_NOTE,
    IMAGE,
    CODE,
    SYSTEM
}

enum class MessageDeliveryStatus {
    SENDING,
    SENT,
    DELIVERED,
    READ
}

data class Message(
    val id: String,
    val conversationId: String, // Chat ID or Channel ID
    val senderId: String,
    val senderName: String,
    val senderColor: Long = 0xFF5865F2,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val type: MessageType = MessageType.TEXT,
    val voiceDurationSec: Int = 0,
    val mediaUri: String? = null,
    val codeLanguage: String? = null,
    val isFromMe: Boolean = false,
    val status: MessageDeliveryStatus = MessageDeliveryStatus.READ,
    val reactions: Map<String, Int> = emptyMap(),
    val replyToMessageId: String? = null,
    val replyToAuthor: String? = null,
    val replyToContent: String? = null,
    val isPinned: Boolean = false
)

data class Chat(
    val id: String,
    val name: String,
    val isGroup: Boolean = false,
    val avatarColor: Long = 0xFF25D366,
    val initials: String = "",
    val lastMessage: String = "",
    val lastMessageTimestamp: Long = System.currentTimeMillis(),
    val unreadCount: Int = 0,
    val isPinned: Boolean = false,
    val isMuted: Boolean = false,
    val contactStatus: UserPresence = UserPresence.ONLINE,
    val isTyping: Boolean = false
)

enum class ChannelType {
    TEXT,
    VOICE,
    ANNOUNCEMENT
}

data class Channel(
    val id: String,
    val serverId: String,
    val name: String,
    val type: ChannelType = ChannelType.TEXT,
    val topic: String = "",
    val category: String = "TEXT CHANNELS",
    val unreadCount: Int = 0
)

data class Server(
    val id: String,
    val name: String,
    val initials: String,
    val iconColor: Long = 0xFF5865F2,
    val bannerDrawableRes: Int? = null,
    val description: String = "",
    val memberCount: Int = 128,
    val onlineCount: Int = 42,
    val channels: List<Channel> = emptyList(),
    val unreadBadge: Boolean = false
)

data class StatusStory(
    val id: String,
    val userId: String,
    val userName: String,
    val userInitials: String,
    val userAvatarColor: Long = 0xFF25D366,
    val contentText: String = "",
    val mediaResId: Int? = null,
    val bgColorHex: Long = 0xFF005C4B,
    val timestamp: Long = System.currentTimeMillis(),
    val isViewed: Boolean = false,
    val isMine: Boolean = false,
    val viewCount: Int = 0
)

data class CallLog(
    val id: String,
    val callerName: String,
    val callerInitials: String,
    val callerColor: Long = 0xFF5865F2,
    val isVideo: Boolean = false,
    val isIncoming: Boolean = true,
    val isMissed: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val durationText: String = "2m 14s"
)

data class VoiceParticipant(
    val id: String,
    val name: String,
    val initials: String,
    val avatarColor: Long = 0xFF5865F2,
    val isSpeaking: Boolean = false,
    val isMuted: Boolean = false,
    val isDeafened: Boolean = false,
    val isScreenSharing: Boolean = false,
    val isCameraOn: Boolean = false
)
