package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.UserAvatar
import com.example.ui.theme.DiscordRed
import com.example.ui.theme.WhatsAppGreen
import com.example.ui.viewmodel.ActiveCallState
import com.example.ui.viewmodel.PulseViewModel

@Composable
fun CallScreen(
    callState: ActiveCallState,
    viewModel: PulseViewModel,
    modifier: Modifier = Modifier
) {
    val durationFormatted = remember(callState.durationSeconds) {
        val mins = callState.durationSeconds / 60
        val secs = callState.durationSeconds % 60
        String.format("%02d:%02d", mins, secs)
    }

    BackHandler {
        viewModel.endCall()
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0D1418),
                        Color(0xFF0F2027),
                        Color(0xFF203A43),
                        Color(0xFF2C5364)
                    )
                )
            )
    ) {
        // Top info
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 60.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = callState.callerName,
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (callState.isVideo) "Pulse Video Call • $durationFormatted" else "Pulse Voice Call • $durationFormatted",
                color = WhatsAppGreen,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
        }

        // Center Content
        if (callState.isVideo && callState.isCameraOn) {
            // Video view
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 130.dp, bottom = 120.dp, start = 16.dp, end = 16.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFF1E293B)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = "Video Feed",
                        tint = WhatsAppGreen,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Live HD Video Connection",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Protected with end-to-end encryption",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            // Large caller avatar
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(160.dp)
            ) {
                UserAvatar(
                    initials = callState.callerInitials,
                    backgroundColor = callState.callerColor,
                    size = 160.dp
                )
            }
        }

        // Bottom Controls
        Surface(
            color = Color.Black.copy(alpha = 0.5f),
            shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp, horizontal = 20.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Speaker
                IconButton(
                    onClick = { viewModel.toggleCallSpeaker() },
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(if (callState.isSpeakerOn) Color.White.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.1f))
                        .testTag("call_speaker_btn")
                ) {
                    Icon(
                        imageVector = if (callState.isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeDown,
                        contentDescription = "Speaker",
                        tint = Color.White
                    )
                }

                // Camera Toggle
                IconButton(
                    onClick = { viewModel.toggleCallCamera() },
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(if (callState.isCameraOn) Color.White.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.1f))
                        .testTag("call_camera_toggle_btn")
                ) {
                    Icon(
                        imageVector = if (callState.isCameraOn) Icons.Default.Videocam else Icons.Default.VideocamOff,
                        contentDescription = "Camera",
                        tint = Color.White
                    )
                }

                // Mute
                IconButton(
                    onClick = { viewModel.toggleCallMute() },
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(if (callState.isMuted) DiscordRed else Color.White.copy(alpha = 0.1f))
                        .testTag("call_mute_toggle_btn")
                ) {
                    Icon(
                        imageVector = if (callState.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute",
                        tint = Color.White
                    )
                }

                // End Call
                IconButton(
                    onClick = { viewModel.endCall() },
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(DiscordRed)
                        .testTag("call_end_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "End Call",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    }
}
