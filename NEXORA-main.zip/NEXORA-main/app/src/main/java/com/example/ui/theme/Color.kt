package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Discord Palette
val DiscordBlurple = Color(0xFF5865F2)
val DiscordGreen = Color(0xFF57F287)
val DiscordYellow = Color(0xFFFEE75C)
val DiscordFuchsia = Color(0xFFEB459E)
val DiscordRed = Color(0xFFED4245)
val DiscordDark = Color(0xFF1E1F22)
val DiscordDarker = Color(0xFF111214)
val DiscordSurface = Color(0xFF2B2D31)
val DiscordCard = Color(0xFF313338)
val DiscordTextPrimary = Color(0xFFF2F3F5)
val DiscordTextSecondary = Color(0xFF949BA4)

// WhatsApp Palette
val WhatsAppGreen = Color(0xFF25D366)
val WhatsAppTeal = Color(0xFF00A884)
val WhatsAppOutgoingBubble = Color(0xFF005C4B)
val WhatsAppIncomingBubble = Color(0xFF202C33)
val WhatsAppDarkBg = Color(0xFF0B141A)
val WhatsAppHeader = Color(0xFF1F2C34)
val WhatsAppTickBlue = Color(0xFF53BDEB)

// Shared Accents
val PulseAccent = Color(0xFF38E54D)
val PulseNeonViolet = Color(0xFF9D4EDD)
val PulseCyberCyan = Color(0xFF00E5FF)
val PulseCardDark = Color(0xFF1B2028)
val PulseDarkBg = Color(0xFF0E1217)

enum class AppThemeMode {
    DISCORD,
    WHATSAPP,
    CYBER_OLED
}
