package com.example.data.repository

import com.example.R
import com.example.data.local.*
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.UUID

class PulseRepository(
    private val pulseDao: PulseDao,
    private val appScope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {

    init {
        appScope.launch {
            seedInitialDataIfNeeded()
        }
    }

    // Conversations / Messages
    fun getMessages(conversationId: String): Flow<List<Message>> {
        return pulseDao.getMessagesForConversation(conversationId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    suspend fun sendMessage(
        conversationId: String,
        content: String,
        type: MessageType = MessageType.TEXT,
        voiceDurationSec: Int = 0,
        mediaUri: String? = null,
        codeLanguage: String? = null,
        replyToMessage: Message? = null
    ): Message {
        val now = System.currentTimeMillis()
        val messageId = "msg_${UUID.randomUUID()}"
        val messageEntity = MessageEntity(
            id = messageId,
            conversationId = conversationId,
            senderId = "me",
            senderName = "You",
            senderColor = 0xFF5865F2,
            content = content,
            timestamp = now,
            type = type.name,
            voiceDurationSec = voiceDurationSec,
            mediaUri = mediaUri,
            codeLanguage = codeLanguage,
            isFromMe = true,
            status = MessageDeliveryStatus.READ.name,
            reactionsJson = "",
            replyToMessageId = replyToMessage?.id,
            replyToAuthor = replyToMessage?.senderName,
            replyToContent = replyToMessage?.content?.take(60),
            isPinned = false
        )
        pulseDao.insertMessage(messageEntity)

        // Update chat preview if it's a chat
        val preview = when (type) {
            MessageType.VOICE_NOTE -> "🎤 Voice note ($voiceDurationSec s)"
            MessageType.IMAGE -> "📷 Photo attachment"
            MessageType.CODE -> "💻 Code snippet"
            else -> content
        }
        pulseDao.updateChatLastMessage(conversationId, preview, now)

        // Schedule auto-reply simulation to make the conversation feel alive!
        simulateResponse(conversationId, content, type)

        return messageEntity.toDomain()
    }

    private fun simulateResponse(conversationId: String, userPrompt: String, type: MessageType) {
        appScope.launch {
            delay(1600) // realistic pause
            val isChannel = conversationId.startsWith("chan_")
            val senderName = if (isChannel) "Nova Bot" else "Alex Rivers"
            val senderId = if (isChannel) "bot_nova" else "user_alex"
            val color = if (isChannel) 0xFF00E5FF else 0xFF25D366

            val replyText = when {
                userPrompt.contains("hello", ignoreCase = true) || userPrompt.contains("hey", ignoreCase = true) ->
                    "Hey there! Ready to jump into the voice lounge or check out the code updates?"
                userPrompt.contains("call", ignoreCase = true) ->
                    "I see you! Let me know if you want to hop on a voice call."
                userPrompt.contains("discord", ignoreCase = true) || userPrompt.contains("server", ignoreCase = true) ->
                    "The Discord side has our #dev-standup and #general-chat running smoothly!"
                userPrompt.contains("whatsapp", ignoreCase = true) || userPrompt.contains("status", ignoreCase = true) ->
                    "Status stories updated! Check the Status tab for today's highlights."
                type == MessageType.VOICE_NOTE ->
                    "Listening to your voice note right now! Clear audio quality."
                type == MessageType.CODE ->
                    "Great code snippet! Clean syntax and architecture."
                else ->
                    "Got it! That looks super sleek. Have you checked out the active voice channel yet?"
            }

            val replyMsg = MessageEntity(
                id = "msg_${UUID.randomUUID()}",
                conversationId = conversationId,
                senderId = senderId,
                senderName = senderName,
                senderColor = color,
                content = replyText,
                timestamp = System.currentTimeMillis(),
                type = MessageType.TEXT.name,
                isFromMe = false,
                status = MessageDeliveryStatus.READ.name,
                reactionsJson = "🔥:1"
            )
            pulseDao.insertMessage(replyMsg)
            pulseDao.updateChatLastMessage(conversationId, replyText, System.currentTimeMillis())
        }
    }

    suspend fun toggleReaction(messageId: String, currentReactions: Map<String, Int>, emoji: String) {
        val updated = currentReactions.toMutableMap()
        val count = updated[emoji] ?: 0
        if (count > 0) {
            updated.remove(emoji)
        } else {
            updated[emoji] = 1
        }
        val json = updated.entries.joinToString(",") { "${it.key}:${it.value}" }
        pulseDao.updateMessageReactions(messageId, json)
    }

    suspend fun togglePin(messageId: String, currentPinned: Boolean) {
        pulseDao.updateMessagePinned(messageId, !currentPinned)
    }

    suspend fun deleteMessage(messageId: String) {
        pulseDao.deleteMessage(messageId)
    }

    // Chats
    fun getAllChats(): Flow<List<Chat>> {
        return pulseDao.getAllChats().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    suspend fun createChat(name: String, isGroup: Boolean): String {
        val id = "chat_${UUID.randomUUID()}"
        val initials = name.split(" ")
            .mapNotNull { it.firstOrNull()?.toString() }
            .take(2).joinToString("").uppercase()
        val chat = ChatEntity(
            id = id,
            name = name,
            isGroup = isGroup,
            avatarColor = if (isGroup) 0xFF5865F2 else 0xFF25D366,
            initials = if (initials.isNotEmpty()) initials else "CH",
            lastMessage = "Started a new conversation",
            lastMessageTimestamp = System.currentTimeMillis(),
            unreadCount = 0
        )
        pulseDao.insertChat(chat)
        return id
    }

    // Servers & Channels
    fun getAllServers(): Flow<List<Server>> {
        return pulseDao.getAllServers().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    fun getChannelsForServer(serverId: String): Flow<List<Channel>> {
        return pulseDao.getChannelsForServer(serverId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    suspend fun createServer(name: String, description: String): String {
        val serverId = "srv_${UUID.randomUUID()}"
        val initials = name.split(" ")
            .mapNotNull { it.firstOrNull()?.toString() }
            .take(2).joinToString("").uppercase()

        val server = ServerEntity(
            id = serverId,
            name = name,
            initials = if (initials.isNotEmpty()) initials else "SRV",
            iconColor = 0xFF5865F2,
            bannerDrawableRes = R.drawable.server_dev_banner,
            description = description,
            memberCount = 1,
            onlineCount = 1
        )
        pulseDao.insertServer(server)

        // Add standard discord channels
        val defaultChannels = listOf(
            ChannelEntity(
                id = "chan_${UUID.randomUUID()}",
                serverId = serverId,
                name = "welcome-and-rules",
                type = ChannelType.ANNOUNCEMENT.name,
                category = "INFORMATION",
                topic = "Welcome to $name!"
            ),
            ChannelEntity(
                id = "chan_${UUID.randomUUID()}",
                serverId = serverId,
                name = "general",
                type = ChannelType.TEXT.name,
                category = "TEXT CHANNELS",
                topic = "General discussion for members"
            ),
            ChannelEntity(
                id = "chan_${UUID.randomUUID()}",
                serverId = serverId,
                name = "General Voice",
                type = ChannelType.VOICE.name,
                category = "VOICE CHANNELS",
                topic = "Drop in and say hi"
            )
        )
        pulseDao.insertChannels(defaultChannels)
        return serverId
    }

    suspend fun createChannel(serverId: String, name: String, type: ChannelType, category: String): String {
        val id = "chan_${UUID.randomUUID()}"
        val channel = ChannelEntity(
            id = id,
            serverId = serverId,
            name = name.lowercase().replace(" ", "-"),
            type = type.name,
            category = category,
            topic = "Discussion in #$name"
        )
        pulseDao.insertChannel(channel)
        return id
    }

    // Status Stories
    fun getAllStories(): Flow<List<StatusStory>> {
        return pulseDao.getAllStories().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    suspend fun postStatusStory(text: String, bgColorHex: Long): String {
        val id = "story_${UUID.randomUUID()}"
        val story = StatusStoryEntity(
            id = id,
            userId = "me",
            userName = "My Status",
            userInitials = "ME",
            userAvatarColor = 0xFF25D366,
            contentText = text,
            bgColorHex = bgColorHex,
            timestamp = System.currentTimeMillis(),
            isViewed = false,
            isMine = true,
            viewCount = 1
        )
        pulseDao.insertStory(story)
        return id
    }

    suspend fun markStoryViewed(storyId: String) {
        pulseDao.markStoryViewed(storyId)
    }

    // Calls
    fun getAllCallLogs(): Flow<List<CallLog>> {
        return pulseDao.getAllCallLogs().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    suspend fun recordCall(callerName: String, isVideo: Boolean, durationText: String) {
        val initials = callerName.split(" ")
            .mapNotNull { it.firstOrNull()?.toString() }
            .take(2).joinToString("").uppercase()
        val log = CallLogEntity(
            id = "call_${UUID.randomUUID()}",
            callerName = callerName,
            callerInitials = if (initials.isNotEmpty()) initials else "CL",
            callerColor = 0xFF5865F2,
            isVideo = isVideo,
            isIncoming = false,
            isMissed = false,
            timestamp = System.currentTimeMillis(),
            durationText = durationText
        )
        pulseDao.insertCallLog(log)
    }

    // Seed Data
    private suspend fun seedInitialDataIfNeeded() {
        // Seed Servers
        val srv1Id = "srv_dev_sanctuary"
        val srv2Id = "srv_cyber_gamers"
        val srv3Id = "srv_lofi_lounge"

        val servers = listOf(
            ServerEntity(
                id = srv1Id,
                name = "Dev Sanctuary",
                initials = "DS",
                iconColor = 0xFF5865F2,
                bannerDrawableRes = R.drawable.server_dev_banner,
                description = "Modern Kotlin, Jetpack Compose, & AI Architecture builders.",
                memberCount = 2840,
                onlineCount = 890,
                unreadBadge = true
            ),
            ServerEntity(
                id = srv2Id,
                name = "Cyber Gamers",
                initials = "CG",
                iconColor = 0xFF9D4EDD,
                bannerDrawableRes = R.drawable.server_gaming_banner,
                description = "Squad up for raids, clips, and esports talk.",
                memberCount = 1420,
                onlineCount = 412,
                unreadBadge = false
            ),
            ServerEntity(
                id = srv3Id,
                name = "Lo-Fi Lounge",
                initials = "LF",
                iconColor = 0xFF00A884,
                bannerDrawableRes = R.drawable.user_nitro_banner,
                description = "Chill vibes, co-working beats, and cozy community.",
                memberCount = 950,
                onlineCount = 230,
                unreadBadge = false
            )
        )
        pulseDao.insertServers(servers)

        // Seed Channels for Dev Sanctuary
        val channels = listOf(
            ChannelEntity("chan_ds_welcome", srv1Id, "announcements", ChannelType.ANNOUNCEMENT.name, "Official releases and roadmap", "INFORMATION"),
            ChannelEntity("chan_ds_general", srv1Id, "general-chat", ChannelType.TEXT.name, "Tech discussions & questions", "TEXT CHANNELS"),
            ChannelEntity("chan_ds_showcase", srv1Id, "project-showcase", ChannelType.TEXT.name, "Show off your latest Android creations", "TEXT CHANNELS"),
            ChannelEntity("chan_ds_voice", srv1Id, "Dev Standup", ChannelType.VOICE.name, "Daily audio sync and live collaboration", "VOICE CHANNELS"),
            ChannelEntity("chan_ds_lofi", srv1Id, "Co-Working Beats", ChannelType.VOICE.name, "24/7 Lo-fi music stream room", "VOICE CHANNELS"),

            // Channels for Cyber Gamers
            ChannelEntity("chan_cg_general", srv2Id, "general", ChannelType.TEXT.name, "Gaming banter & squad setups", "TEXT CHANNELS"),
            ChannelEntity("chan_cg_clips", srv2Id, "clips-and-highlights", ChannelType.TEXT.name, "Share your winning moments", "TEXT CHANNELS"),
            ChannelEntity("chan_cg_squad1", srv2Id, "Squad Alpha", ChannelType.VOICE.name, "Active voice comms", "VOICE CHANNELS"),

            // Channels for Lo-Fi Lounge
            ChannelEntity("chan_lf_chat", srv3Id, "cozy-corner", ChannelType.TEXT.name, "Warm greetings and tea chats", "TEXT CHANNELS"),
            ChannelEntity("chan_lf_listen", srv3Id, "Study Room 1", ChannelType.VOICE.name, "Quiet study & focus lounge", "VOICE CHANNELS")
        )
        pulseDao.insertChannels(channels)

        // Seed WhatsApp Chats
        val chats = listOf(
            ChatEntity(
                id = "chat_alex",
                name = "Alex Rivers",
                isGroup = false,
                avatarColor = 0xFF25D366,
                initials = "AR",
                lastMessage = "Hey! Have you tried the Discord voice lounge yet?",
                lastMessageTimestamp = System.currentTimeMillis() - 1000 * 60 * 5,
                unreadCount = 2,
                isPinned = true,
                contactStatus = "ONLINE"
            ),
            ChatEntity(
                id = "chat_sarah",
                name = "Sarah Chen (Design)",
                isGroup = false,
                avatarColor = 0xFF5865F2,
                initials = "SC",
                lastMessage = "Sent the new M3 gradient specs! Looks super crisp 🔥",
                lastMessageTimestamp = System.currentTimeMillis() - 1000 * 60 * 30,
                unreadCount = 1,
                isPinned = true,
                contactStatus = "IDLE"
            ),
            ChatEntity(
                id = "chat_android_guild",
                name = "Android Guild 🚀",
                isGroup = true,
                avatarColor = 0xFF00E5FF,
                initials = "AG",
                lastMessage = "Marcus: Just merged the voice waveform animation PR!",
                lastMessageTimestamp = System.currentTimeMillis() - 1000 * 60 * 90,
                unreadCount = 5,
                isPinned = false,
                contactStatus = "ONLINE"
            ),
            ChatEntity(
                id = "chat_claire",
                name = "Claire Vance",
                isGroup = false,
                avatarColor = 0xFFEB459E,
                initials = "CV",
                lastMessage = "See you in the voice room later tonight! 🎧",
                lastMessageTimestamp = System.currentTimeMillis() - 1000 * 60 * 240,
                unreadCount = 0,
                isPinned = false,
                contactStatus = "OFFLINE"
            )
        )
        pulseDao.insertChats(chats)

        // Seed Messages for Alex
        val alexMessages = listOf(
            MessageEntity(
                id = "msg_a1",
                conversationId = "chat_alex",
                senderId = "alex",
                senderName = "Alex Rivers",
                senderColor = 0xFF25D366,
                content = "Hey! Welcome to Pulse. Combining WhatsApp simplicity with Discord servers is genial!",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 15,
                type = MessageType.TEXT.name,
                isFromMe = false,
                reactionsJson = "❤️:2,🚀:3"
            ),
            MessageEntity(
                id = "msg_a2",
                conversationId = "chat_alex",
                senderId = "me",
                senderName = "You",
                senderColor = 0xFF5865F2,
                content = "Totally! Love how we have voice notes and voice lounges in one single place.",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 10,
                type = MessageType.TEXT.name,
                isFromMe = true,
                reactionsJson = "👍:1"
            ),
            MessageEntity(
                id = "msg_a3",
                conversationId = "chat_alex",
                senderId = "alex",
                senderName = "Alex Rivers",
                senderColor = 0xFF25D366,
                content = "Check out this voice note I left for the dev sync:",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 7,
                type = MessageType.VOICE_NOTE.name,
                voiceDurationSec = 14,
                isFromMe = false,
                reactionsJson = "🔥:4"
            ),
            MessageEntity(
                id = "msg_a4",
                conversationId = "chat_alex",
                senderId = "alex",
                senderName = "Alex Rivers",
                senderColor = 0xFF25D366,
                content = "Hey! Have you tried the Discord voice lounge yet?",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 5,
                type = MessageType.TEXT.name,
                isFromMe = false
            )
        )
        pulseDao.insertMessages(alexMessages)

        // Seed Messages for #general-chat in Dev Sanctuary
        val dsGeneralMessages = listOf(
            MessageEntity(
                id = "msg_ds1",
                conversationId = "chan_ds_general",
                senderId = "marcus_k",
                senderName = "Marcus [Lead]",
                senderColor = 0xFFFEE75C,
                content = "Welcome everyone to Dev Sanctuary! Here is the clean architecture snippet we are using for Pulse:",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 60,
                type = MessageType.CODE.name,
                codeLanguage = "Kotlin",
                isFromMe = false,
                reactionsJson = "🔥:8,💯:5"
            ),
            MessageEntity(
                id = "msg_ds2",
                conversationId = "chan_ds_general",
                senderId = "sarah_c",
                senderName = "Sarah Chen",
                senderColor = 0xFFEB459E,
                content = "Voice lounges support interactive soundboard effects (🎺 Airhorn, 👏 Applause, 🥁 Ba-Dum-Tss)!",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 45,
                type = MessageType.TEXT.name,
                isFromMe = false,
                reactionsJson = "🎉:6"
            ),
            MessageEntity(
                id = "msg_ds3",
                conversationId = "chan_ds_general",
                senderId = "bot_nova",
                senderName = "Nova Bot",
                senderColor = 0xFF00E5FF,
                content = "⚡ Server Tip: You can switch between Discord Blurple, WhatsApp Emerald, and Cyber OLED themes anytime in Settings!",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 20,
                type = MessageType.SYSTEM.name,
                isFromMe = false,
                isPinned = true
            )
        )
        pulseDao.insertMessages(dsGeneralMessages)

        // Seed Status Stories (WhatsApp style)
        val stories = listOf(
            StatusStoryEntity(
                id = "story_mine",
                userId = "me",
                userName = "My Status",
                userInitials = "ME",
                userAvatarColor = 0xFF25D366,
                contentText = "Testing the new Pulse hybrid app 🚀 WhatsApp + Discord unified!",
                bgColorHex = 0xFF005C4B,
                timestamp = System.currentTimeMillis() - 1000 * 60 * 120,
                isViewed = true,
                isMine = true,
                viewCount = 18
            ),
            StatusStoryEntity(
                id = "story_alex",
                userId = "user_alex",
                userName = "Alex Rivers",
                userInitials = "AR",
                userAvatarColor = 0xFF25D366,
                contentText = "Chilling in the Lo-Fi voice room. Come drop by! 🎧☕",
                bgColorHex = 0xFF5865F2,
                timestamp = System.currentTimeMillis() - 1000 * 60 * 45,
                isViewed = false,
                isMine = false,
                viewCount = 42
            ),
            StatusStoryEntity(
                id = "story_sarah",
                userId = "user_sarah",
                userName = "Sarah Chen",
                userInitials = "SC",
                userAvatarColor = 0xFFEB459E,
                contentText = "New UI mockup finished. Check out the dark neon aesthetics ✨",
                bgColorHex = 0xFF9D4EDD,
                timestamp = System.currentTimeMillis() - 1000 * 60 * 180,
                isViewed = false,
                isMine = false,
                viewCount = 65
            )
        )
        pulseDao.insertStories(stories)

        // Seed Call Logs
        val callLogs = listOf(
            CallLogEntity(
                id = "call_1",
                callerName = "Alex Rivers",
                callerInitials = "AR",
                callerColor = 0xFF25D366,
                isVideo = true,
                isIncoming = true,
                isMissed = false,
                timestamp = System.currentTimeMillis() - 1000 * 60 * 60 * 3,
                durationText = "14m 22s"
            ),
            CallLogEntity(
                id = "call_2",
                callerName = "Sarah Chen",
                callerInitials = "SC",
                callerColor = 0xFF5865F2,
                isVideo = false,
                isIncoming = false,
                isMissed = false,
                timestamp = System.currentTimeMillis() - 1000 * 60 * 60 * 18,
                durationText = "6m 40s"
            ),
            CallLogEntity(
                id = "call_3",
                callerName = "Dev Standup",
                callerInitials = "DS",
                callerColor = 0xFF00E5FF,
                isVideo = false,
                isIncoming = true,
                isMissed = true,
                timestamp = System.currentTimeMillis() - 1000 * 60 * 60 * 26,
                durationText = "Missed call"
            )
        )
        pulseDao.insertCallLogs(callLogs)
    }

    // Entity to Domain mappers
    private fun MessageEntity.toDomain(): Message {
        val reactionsMap = if (reactionsJson.isBlank()) emptyMap() else {
            reactionsJson.split(",").mapNotNull { entry ->
                val parts = entry.split(":")
                if (parts.size == 2) parts[0] to (parts[1].toIntOrNull() ?: 1) else null
            }.toMap()
        }
        return Message(
            id = id,
            conversationId = conversationId,
            senderId = senderId,
            senderName = senderName,
            senderColor = senderColor,
            content = content,
            timestamp = timestamp,
            type = MessageType.valueOf(type),
            voiceDurationSec = voiceDurationSec,
            mediaUri = mediaUri,
            codeLanguage = codeLanguage,
            isFromMe = isFromMe,
            status = MessageDeliveryStatus.valueOf(status),
            reactions = reactionsMap,
            replyToMessageId = replyToMessageId,
            replyToAuthor = replyToAuthor,
            replyToContent = replyToContent,
            isPinned = isPinned
        )
    }

    private fun ChatEntity.toDomain(): Chat {
        return Chat(
            id = id,
            name = name,
            isGroup = isGroup,
            avatarColor = avatarColor,
            initials = initials,
            lastMessage = lastMessage,
            lastMessageTimestamp = lastMessageTimestamp,
            unreadCount = unreadCount,
            isPinned = isPinned,
            isMuted = isMuted,
            contactStatus = UserPresence.valueOf(contactStatus)
        )
    }

    private fun ServerEntity.toDomain(): Server {
        return Server(
            id = id,
            name = name,
            initials = initials,
            iconColor = iconColor,
            bannerDrawableRes = bannerDrawableRes,
            description = description,
            memberCount = memberCount,
            onlineCount = onlineCount,
            unreadBadge = unreadBadge
        )
    }

    private fun ChannelEntity.toDomain(): Channel {
        return Channel(
            id = id,
            serverId = serverId,
            name = name,
            type = ChannelType.valueOf(type),
            topic = topic,
            category = category,
            unreadCount = unreadCount
        )
    }

    private fun StatusStoryEntity.toDomain(): StatusStory {
        return StatusStory(
            id = id,
            userId = userId,
            userName = userName,
            userInitials = userInitials,
            userAvatarColor = userAvatarColor,
            contentText = contentText,
            mediaResId = mediaResId,
            bgColorHex = bgColorHex,
            timestamp = timestamp,
            isViewed = isViewed,
            isMine = isMine,
            viewCount = viewCount
        )
    }

    private fun CallLogEntity.toDomain(): CallLog {
        return CallLog(
            id = id,
            callerName = callerName,
            callerInitials = callerInitials,
            callerColor = callerColor,
            isVideo = isVideo,
            isIncoming = isIncoming,
            isMissed = isMissed,
            timestamp = timestamp,
            durationText = durationText
        )
    }
}
