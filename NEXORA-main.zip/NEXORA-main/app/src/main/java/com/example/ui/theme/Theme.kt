package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DiscordColorScheme = darkColorScheme(
    primary = DiscordBlurple,
    onPrimary = Color.White,
    primaryContainer = DiscordSurface,
    onPrimaryContainer = DiscordTextPrimary,
    secondary = DiscordGreen,
    onSecondary = Color.Black,
    secondaryContainer = DiscordCard,
    onSecondaryContainer = DiscordTextPrimary,
    tertiary = DiscordYellow,
    background = DiscordDarker,
    onBackground = DiscordTextPrimary,
    surface = DiscordDark,
    onSurface = DiscordTextPrimary,
    surfaceVariant = DiscordSurface,
    onSurfaceVariant = DiscordTextSecondary,
    outline = Color(0xFF3F4147)
)

private val WhatsAppColorScheme = darkColorScheme(
    primary = WhatsAppGreen,
    onPrimary = Color.Black,
    primaryContainer = WhatsAppTeal,
    onPrimaryContainer = Color.White,
    secondary = WhatsAppTeal,
    onSecondary = Color.White,
    secondaryContainer = WhatsAppIncomingBubble,
    onSecondaryContainer = Color.White,
    tertiary = WhatsAppTickBlue,
    background = WhatsAppDarkBg,
    onBackground = Color(0xFFE9EDEF),
    surface = WhatsAppHeader,
    onSurface = Color(0xFFE9EDEF),
    surfaceVariant = WhatsAppIncomingBubble,
    onSurfaceVariant = Color(0xFF8696A0),
    outline = Color(0xFF222D34)
)

private val CyberColorScheme = darkColorScheme(
    primary = PulseCyberCyan,
    onPrimary = Color.Black,
    primaryContainer = PulseCardDark,
    onPrimaryContainer = PulseCyberCyan,
    secondary = PulseNeonViolet,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF1F1A30),
    onSecondaryContainer = PulseNeonViolet,
    tertiary = PulseAccent,
    background = Color(0xFF090A0F),
    onBackground = Color(0xFFF0F4F8),
    surface = Color(0xFF12141C),
    onSurface = Color(0xFFF0F4F8),
    surfaceVariant = Color(0xFF1A1D27),
    onSurfaceVariant = Color(0xFF9098A9),
    outline = Color(0xFF2A2E3D)
)

@Composable
fun PulseAppTheme(
    themeMode: AppThemeMode = AppThemeMode.DISCORD,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        AppThemeMode.DISCORD -> DiscordColorScheme
        AppThemeMode.WHATSAPP -> WhatsAppColorScheme
        AppThemeMode.CYBER_OLED -> CyberColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = PulseTypography,
        content = content
    )
}
