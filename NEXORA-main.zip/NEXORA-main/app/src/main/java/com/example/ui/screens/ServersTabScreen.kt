package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Channel
import com.example.data.model.ChannelType
import com.example.data.model.Server
import com.example.ui.theme.*
import com.example.ui.viewmodel.PulseViewModel

@Composable
fun ServersTabScreen(
    viewModel: PulseViewModel,
    modifier: Modifier = Modifier
) {
    val servers by viewModel.allServers.collectAsState()
    val selectedServerId by viewModel.selectedServerId.collectAsState()
    val channels by viewModel.currentServerChannels.collectAsState()

    val currentServer = remember(servers, selectedServerId) {
        servers.find { it.id == selectedServerId } ?: servers.firstOrNull()
    }

    var showCreateServerDialog by remember { mutableStateOf(false) }
    var showCreateChannelDialog by remember { mutableStateOf(false) }

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(DiscordDarker)
    ) {
        // Left Discord Server Rail
        Column(
            modifier = Modifier
                .width(76.dp)
                .fillMaxHeight()
                .background(DiscordDark)
                .padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Pulse Hub Icon
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(DiscordBlurple)
                    .testTag("server_rail_home"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Stream,
                    contentDescription = "Pulse Home",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(
                modifier = Modifier.width(36.dp),
                thickness = 2.dp,
                color = DiscordCard
            )
            Spacer(modifier = Modifier.height(10.dp))

            // Server Icons
            LazyColumn(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(servers, key = { it.id }) { server ->
                    val isSelected = server.id == selectedServerId
                    ServerRailItem(
                        server = server,
                        isSelected = isSelected,
                        onClick = { viewModel.selectServer(server.id) }
                    )
                }

                item {
                    // Add Server Button
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(DiscordCard)
                            .clickable { showCreateServerDialog = true }
                            .testTag("add_server_rail_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Server",
                            tint = DiscordGreen,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }

        // Right Channel and Content Pane
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .background(DiscordSurface)
        ) {
            if (currentServer != null) {
                // Server Header with Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                ) {
                    if (currentServer.bannerDrawableRes != null) {
                        Image(
                            painter = painterResource(id = currentServer.bannerDrawableRes),
                            contentDescription = currentServer.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color(currentServer.iconColor), DiscordSurface)
                                    )
                                )
                        )
                    }

                    // Gradient overlay
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, DiscordSurface)
                                )
                            )
                    )

                    // Header Info
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(14.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = currentServer.name,
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.Default.Verified,
                                    contentDescription = "Verified Server",
                                    tint = DiscordBlurple,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                text = "🟢 ${currentServer.onlineCount} Online • ${currentServer.memberCount} Members",
                                color = DiscordTextSecondary,
                                fontSize = 11.sp
                            )
                        }

                        IconButton(
                            onClick = { showCreateChannelDialog = true },
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(DiscordCard.copy(alpha = 0.8f))
                                .testTag("btn_create_channel")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add Channel",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // Channels List grouped by Category
                val groupedChannels = remember(channels) {
                    channels.groupBy { it.category }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 8.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    groupedChannels.forEach { (category, categoryChannels) ->
                        item {
                            Text(
                                text = category.uppercase(),
                                color = DiscordTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }

                        items(categoryChannels, key = { it.id }) { channel ->
                            ChannelItemRow(
                                channel = channel,
                                onClick = {
                                    viewModel.openChannel(channel, currentServer.name)
                                }
                            )
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Select or create a server", color = DiscordTextSecondary)
                }
            }
        }
    }

    if (showCreateServerDialog) {
        CreateServerDialog(
            onDismiss = { showCreateServerDialog = false },
            onCreate = { name, desc ->
                viewModel.createServer(name, desc)
                showCreateServerDialog = false
            }
        )
    }

    if (showCreateChannelDialog && currentServer != null) {
        CreateChannelDialog(
            serverName = currentServer.name,
            onDismiss = { showCreateChannelDialog = false },
            onCreate = { name, type, category ->
                viewModel.createChannel(name, type, category)
                showCreateChannelDialog = false
            }
        )
    }
}

@Composable
fun ServerRailItem(
    server: Server,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val cornerRadius by animateDpAsState(
        targetValue = if (isSelected) 16.dp else 25.dp,
        label = "corner_radius"
    )

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("server_item_${server.id}")
    ) {
        // Selection pill indicator on the left
        Box(
            modifier = Modifier
                .width(4.dp)
                .height(if (isSelected) 36.dp else 8.dp)
                .clip(RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp))
                .background(if (isSelected) Color.White else Color.Transparent)
        )

        Spacer(modifier = Modifier.width(6.dp))

        Box(
            modifier = Modifier
                .size(50.dp)
                .clip(RoundedCornerShape(cornerRadius))
                .background(
                    if (isSelected) DiscordBlurple else Color(server.iconColor)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = server.initials,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }
    }
}

@Composable
fun ChannelItemRow(
    channel: Channel,
    onClick: () -> Unit
) {
    val icon = when (channel.type) {
        ChannelType.TEXT -> Icons.Default.Tag
        ChannelType.VOICE -> Icons.Default.VolumeUp
        ChannelType.ANNOUNCEMENT -> Icons.Default.Campaign
    }

    val iconColor = when (channel.type) {
        ChannelType.TEXT -> DiscordTextSecondary
        ChannelType.VOICE -> DiscordGreen
        ChannelType.ANNOUNCEMENT -> DiscordYellow
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .testTag("channel_${channel.id}"),
        color = Color.Transparent
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = channel.type.name,
                tint = iconColor,
                modifier = Modifier.size(18.dp)
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = channel.name,
                    color = DiscordTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (channel.type == ChannelType.VOICE) {
                    Text(
                        text = "Tap to join voice room 🔊",
                        color = DiscordGreen,
                        fontSize = 11.sp
                    )
                }
            }

            if (channel.unreadCount > 0) {
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(DiscordRed)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${channel.unreadCount}",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun CreateServerDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, desc: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Your Discord Server") },
        text = {
            Column {
                Text(
                    "Your server is where you and your friends hang out. Make yours and start talking.",
                    color = DiscordTextSecondary,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(14.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Server Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("create_server_name_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("Server Description") },
                    modifier = Modifier.fillMaxWidth().testTag("create_server_desc_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (name.isNotBlank()) onCreate(name.trim(), desc.trim()) },
                enabled = name.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = DiscordBlurple),
                modifier = Modifier.testTag("create_server_confirm_button")
            ) {
                Text("Create Server")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun CreateChannelDialog(
    serverName: String,
    onDismiss: () -> Unit,
    onCreate: (name: String, type: ChannelType, category: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(ChannelType.TEXT) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Channel in $serverName") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Channel Name") },
                    placeholder = { Text("new-channel") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("create_channel_name_input")
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text("CHANNEL TYPE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DiscordTextSecondary)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selectedType == ChannelType.TEXT) DiscordCard else Color.Transparent)
                        .clickable { selectedType = ChannelType.TEXT }
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedType == ChannelType.TEXT,
                        onClick = { selectedType = ChannelType.TEXT }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("Text Channel", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("Post images, stickers, opinions, and puns", color = DiscordTextSecondary, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selectedType == ChannelType.VOICE) DiscordCard else Color.Transparent)
                        .clickable { selectedType = ChannelType.VOICE }
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = selectedType == ChannelType.VOICE,
                        onClick = { selectedType = ChannelType.VOICE }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("Voice Channel", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("Hang out together with voice, video, and screen share", color = DiscordTextSecondary, fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val category = if (selectedType == ChannelType.VOICE) "VOICE CHANNELS" else "TEXT CHANNELS"
                        onCreate(name.trim(), selectedType, category)
                    }
                },
                enabled = name.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = DiscordBlurple),
                modifier = Modifier.testTag("create_channel_confirm_button")
            ) {
                Text("Create Channel")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
