package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.UserPresence
import com.example.ui.components.UserAvatar
import com.example.ui.theme.*
import com.example.ui.viewmodel.PulseViewModel

@Composable
fun ProfileTabScreen(
    viewModel: PulseViewModel,
    modifier: Modifier = Modifier
) {
    val themeMode by viewModel.themeMode.collectAsState()
    val userStatus by viewModel.userStatus.collectAsState()
    val customStatusText by viewModel.customStatusText.collectAsState()

    var showEditStatusDialog by remember { mutableStateOf(false) }
    var soundEnabled by remember { mutableStateOf(true) }
    var readReceiptsEnabled by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Hero Nitro Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.user_nitro_banner),
                    contentDescription = "Profile Banner",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                )

                // Avatar overlapping banner (Discord / WhatsApp profile style)
                Box(
                    modifier = Modifier
                        .padding(start = 20.dp)
                        .align(Alignment.BottomStart)
                        .size(80.dp)
                        .clip(CircleShape)
                        .border(3.5.dp, MaterialTheme.colorScheme.background, CircleShape)
                ) {
                    UserAvatar(
                        initials = "ME",
                        backgroundColor = 0xFF5865F2,
                        size = 80.dp,
                        presence = userStatus
                    )
                }

                // Nitro Badge Pill on top right
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DiscordFuchsia,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "Nitro",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("NITRO", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // User Identity
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Pulse Pioneer",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = "Verified",
                        tint = DiscordBlurple,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Text(
                    text = "@pulse_builder • Pulse Founder ⚡",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Custom Status Bar
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showEditStatusDialog = true }
                        .testTag("custom_status_card")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("💬", fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = customStatusText,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit status",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // Online Status Selector (Discord style)
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "SET ONLINE STATUS",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StatusOptionRow(
                    title = "Online",
                    subtitle = "Visible as active and available",
                    dotColor = DiscordGreen,
                    isSelected = userStatus == UserPresence.ONLINE,
                    onClick = { viewModel.setUserStatus(UserPresence.ONLINE) }
                )
                StatusOptionRow(
                    title = "Idle",
                    subtitle = "Away from keyboard",
                    dotColor = DiscordYellow,
                    isSelected = userStatus == UserPresence.IDLE,
                    onClick = { viewModel.setUserStatus(UserPresence.IDLE) }
                )
                StatusOptionRow(
                    title = "Do Not Disturb",
                    subtitle = "Mute incoming notifications",
                    dotColor = DiscordRed,
                    isSelected = userStatus == UserPresence.DND,
                    onClick = { viewModel.setUserStatus(UserPresence.DND) }
                )
                StatusOptionRow(
                    title = "Invisible",
                    subtitle = "Appear offline to everyone",
                    dotColor = Color.Gray,
                    isSelected = userStatus == UserPresence.OFFLINE,
                    onClick = { viewModel.setUserStatus(UserPresence.OFFLINE) }
                )
            }
        }

        // Theme Customizer
        item {
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = "APP THEME & VIBE",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ThemeCard(
                    title = "Discord",
                    subtitle = "Dark Blurple",
                    accentColor = DiscordBlurple,
                    isSelected = themeMode == AppThemeMode.DISCORD,
                    onClick = { viewModel.setTheme(AppThemeMode.DISCORD) },
                    modifier = Modifier.weight(1f)
                )

                ThemeCard(
                    title = "WhatsApp",
                    subtitle = "Dark Emerald",
                    accentColor = WhatsAppGreen,
                    isSelected = themeMode == AppThemeMode.WHATSAPP,
                    onClick = { viewModel.setTheme(AppThemeMode.WHATSAPP) },
                    modifier = Modifier.weight(1f)
                )

                ThemeCard(
                    title = "Cyber",
                    subtitle = "Neon OLED",
                    accentColor = PulseCyberCyan,
                    isSelected = themeMode == AppThemeMode.CYBER_OLED,
                    onClick = { viewModel.setTheme(AppThemeMode.CYBER_OLED) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Preferences & Switches
        item {
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = "PREFERENCES",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Voice & Soundboard Audio", fontWeight = FontWeight.Medium, fontSize = 14.sp)
                            Text("Play sound effects in voice lounge", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = soundEnabled,
                            onCheckedChange = { soundEnabled = it }
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Read Receipts (Blue Checks)", fontWeight = FontWeight.Medium, fontSize = 14.sp)
                            Text("Show double ticks when seen", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = readReceiptsEnabled,
                            onCheckedChange = { readReceiptsEnabled = it }
                        )
                    }
                }
            }
        }
    }

    if (showEditStatusDialog) {
        var newStatusText by remember { mutableStateOf(customStatusText) }
        AlertDialog(
            onDismissRequest = { showEditStatusDialog = false },
            title = { Text("Set Custom Status") },
            text = {
                OutlinedTextField(
                    value = newStatusText,
                    onValueChange = { newStatusText = it },
                    label = { Text("What are you doing?") },
                    placeholder = { Text("Listening to Spotify 🎧") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("edit_status_input")
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setCustomStatusText(newStatusText)
                        showEditStatusDialog = false
                    },
                    modifier = Modifier.testTag("save_status_button")
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditStatusDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun StatusOptionRow(
    title: String,
    subtitle: String,
    dotColor: Color,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = subtitle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }

            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Selected",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun ThemeCard(
    title: String,
    subtitle: String,
    accentColor: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = modifier
            .border(
                width = if (isSelected) 2.dp else 0.dp,
                color = if (isSelected) accentColor else Color.Transparent,
                shape = RoundedCornerShape(14.dp)
            )
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(accentColor)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
        }
    }
}
