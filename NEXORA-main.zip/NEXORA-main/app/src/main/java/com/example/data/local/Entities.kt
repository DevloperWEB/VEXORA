package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val senderId: String,
    val senderName: String,
    val senderColor: Long,
    val content: String,
    val timestamp: Long,
    val type: String, // TEXT, VOICE_NOTE, IMAGE, CODE, SYSTEM
    val voiceDurationSec: Int = 0,
    val mediaUri: String? = null,
    val codeLanguage: String? = null,
    val isFromMe: Boolean = false,
    val status: String = "READ",
    val reactionsJson: String = "", // e.g. "❤️:2,🔥:5"
    val replyToMessageId: String? = null,
    val replyToAuthor: String? = null,
    val replyToContent: String? = null,
    val isPinned: Boolean = false
)

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey val id: String,
    val name: String,
    val isGroup: Boolean,
    val avatarColor: Long,
    val initials: String,
    val lastMessage: String,
    val lastMessageTimestamp: Long,
    val unreadCount: Int = 0,
    val isPinned: Boolean = false,
    val isMuted: Boolean = false,
    val contactStatus: String = "ONLINE"
)

@Entity(tableName = "servers")
data class ServerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val initials: String,
    val iconColor: Long,
    val bannerDrawableRes: Int? = null,
    val description: String,
    val memberCount: Int = 120,
    val onlineCount: Int = 35,
    val unreadBadge: Boolean = false
)

@Entity(tableName = "channels")
data class ChannelEntity(
    @PrimaryKey val id: String,
    val serverId: String,
    val name: String,
    val type: String, // TEXT, VOICE, ANNOUNCEMENT
    val topic: String = "",
    val category: String = "TEXT CHANNELS",
    val unreadCount: Int = 0
)

@Entity(tableName = "status_stories")
data class StatusStoryEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val userName: String,
    val userInitials: String,
    val userAvatarColor: Long,
    val contentText: String,
    val mediaResId: Int? = null,
    val bgColorHex: Long,
    val timestamp: Long,
    val isViewed: Boolean = false,
    val isMine: Boolean = false,
    val viewCount: Int = 0
)

@Entity(tableName = "call_logs")
data class CallLogEntity(
    @PrimaryKey val id: String,
    val callerName: String,
    val callerInitials: String,
    val callerColor: Long,
    val isVideo: Boolean,
    val isIncoming: Boolean,
    val isMissed: Boolean,
    val timestamp: Long,
    val durationText: String
)
