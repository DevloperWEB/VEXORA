# NEXORA - WhatsApp + Discord Unified Messenger

**NEXORA** is a next-generation Android messaging and community platform built entirely with **Kotlin**, **Jetpack Compose**, and **Room Database**. It harmoniously fuses WhatsApp's direct messaging simplicity, voice notes, and status stories with Discord's rich server hierarchies, channels, and interactive voice lounges.

---

## 🌟 Core Highlights & Architecture

### 1. 💬 WhatsApp Direct Messaging & Groups
- **Chat Types**: Direct 1-on-1 private messaging and multi-member group chats.
- **Filter Chips & Instant Search**: Filter quickly across `All`, `Unread`, and `Groups` with real-time text query filtering.
- **Read Receipts**: Visual message delivery states (Sent, Delivered, and WhatsApp Double-Check Blue Ticks).
- **Audio Voice Notes**:
  - Live recording with timer feedback and instant send/discard options.
  - Interactive playback engine featuring dynamic animated audio waveforms and speed switching (`1.0x`, `1.5x`, `2.0x`).
- **Rich Message Actions**:
  - Long-press menu with quick emoji reactions (`❤️`, `🔥`, `👍`, `😂`, `🎉`, `💯`).
  - Reply quoting and threaded context display.
  - One-tap text copying to system clipboard.
  - Message pinning and deletion.
- **Interactive Auto-Responses**: Integrated contextual simulated contacts and bot responses for realistic chat flows.

### 2. 🎮 Discord Servers & Community Channels
- **Vertical Server Rail**: Discord-style left server navigation with rounded indicator pills, active selection squircle animations, and server creation.
- **Hero Server Banners**: Visual header artwork for servers (`Dev Sanctuary`, `Cyber Gamers`, `Lo-Fi Lounge`).
- **Channel Categories**: Organized channels under `INFORMATION`, `TEXT CHANNELS`, and `VOICE CHANNELS`.
- **Text Channels (`#`) & Voice Channels (`🔊`)**: Seamless switching between channel threads and voice lounges.
- **Code Snippets**: Discord-style syntax highlighted code blocks rendered in monospace typography with copy-to-clipboard functionality.

### 3. 🎙️ Discord Voice Lounge & Soundboard
- **Active Participant Grid**: Grid of connected participants with real-time speaking halation rings (`Canvas` wave animation).
- **Controls**: In-call microphone mute, headset deafen, live camera toggle, and screen share preview simulation.
- **Interactive Soundboard**: Instant soundboard trigger with ripple feedback and banner announcements:
  - 🎺 *Airhorn*
  - 🎮 *GG*
  - 👏 *Applause*
  - 🥁 *Ba-Dum-Tss*
  - 🦆 *Quack*
  - 🔔 *Ding*
- **Persistent Voice Floating Bar**: Global floating bottom bar keeping voice channel controls active while browsing other chats and servers.

### 4. ⭕ WhatsApp 24-Hour Status Stories
- **"My Status" Tracker**: Post custom status stories and track viewer counts.
- **Story Composer**: Custom text status creation with multiple background color gradients (Emerald, Blurple, Neon Violet, Fuchsia, Crimson, Dark Slate).
- **Segmented Full-Screen Viewer**: Timed story progress bars with hold-to-pause and direct reply messaging.

### 5. 📞 Encrypted Audio & Video Calls
- **1-on-1 Full-Screen Calling**: HD Audio and Video call interface with live duration counter.
- **Call Controls**: Front/back camera toggle, speakerphone switcher, microphone mute, and one-tap hangup.
- **Call History**: Comprehensive log tracking incoming, outgoing, and missed calls with one-tap callback.

### 6. 🎨 Vibe & Theme Customizer
- **Triple Theme Switcher**:
  - 🟣 **Discord Dark** (Discord Blurple & Slate tones)
  - 🟢 **WhatsApp Emerald** (Forest Green & Teal tones)
  - ⚡ **Cyber OLED** (Pitch Black & Neon Cyan)
- **User Presence**: Live status mode selector (🟢 *Online*, 🟡 *Idle*, 🔴 *Do Not Disturb*, ⚪ *Invisible*).
- **Custom Status**: Personal customizable status message.

---

## 🛠️ Tech Stack & Requirements

- **Language**: Kotlin 2.2+
- **UI Toolkit**: Jetpack Compose (Material 3)
- **Local Persistence**: Android Room Database 2.7 with KSP (Kotlin Symbol Processing)
- **Reactive Streams**: Kotlin Coroutines & `StateFlow` / `Flow`
- **Fonts**: Inter (Sans-serif display & body) & JetBrains Mono (Code blocks)
- **Image Loading**: Coil 2.7
- **Min SDK**: 24 (Android 7.0+)
- **Target / Compile SDK**: 36 (Android 15+)

---

## 🚀 How to Build & Run Locally

1. **Prerequisites**:
   - Android Studio Ladybug / Meerkat or later
   - JDK 11 or 17
   - Android SDK with API Level 34+ installed

2. **Open in Android Studio**:
   - Launch Android Studio.
   - Choose **Open an Existing Project** and select this directory.
   - Wait for Gradle sync to complete automatically.

3. **Run on Emulator / Physical Device**:
   - Connect an Android device with USB debugging enabled, or launch an Android Virtual Device (AVD).
   - Click the green **Run** (Play) button or press `Shift + F10`.

4. **Command Line Build**:
   ```bash
   # Assemble Debug APK
   ./gradlew assembleDebug

   # Run Unit and Robolectric Tests
   ./gradlew :app:testDebugUnitTest
   ```
   The generated APK will be located at:
   `app/build/outputs/apk/debug/app-debug.apk`

---

## 📦 How to Download or Export as a ZIP

To export the entire working NEXORA project from Google AI Studio:
1. Locate the **top-right navigation or settings toolbar** in your AI Studio window.
2. Click on the **Download / Export** icon (or access the project settings dropdown menu).
3. Select **"Download as ZIP"** (or **"Export Project"**).
4. Extract the ZIP file anywhere on your computer and open the folder directly in **Android Studio**.
